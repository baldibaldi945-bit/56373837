"""V-Slice (Polymod) mod  ->  Psych Engine 1.0.x mod.   python3 vslice_to_psych.py <mod.zip|folder> <out_dir>"""
import json, os, re, shutil, subprocess, sys, zipfile, glob, colorsys
from PIL import Image
from . import atlas as A
from . import ai as AI
from . import hx2lua
from . import credits as C

HERE = os.path.dirname(os.path.abspath(__file__))
METHODS = json.load(open(os.path.join(HERE, 'methods.json'), encoding='utf-8'))['vslice']
CREDIT_EN = 'This mod was ported by the AxelzeroX23 app (PortYou Studio)'
CREDIT_PT = 'Este mod foi portado pelo app do AxelzeroX23 (PortYou Studio)'


def slug(s, fallback='mod'):
    r = re.sub(r'[^a-z0-9_-]+', '-', s.lower()).strip('-')
    return r if sum(c.isalnum() for c in r) >= 2 else fallback


def lua_str(s):
    return "'" + str(s).replace('\\', '\\\\').replace("'", "\\'") + "'"


def jload(p):
    return A.load_json(p)


def jsave(p, d):
    os.makedirs(os.path.dirname(p), exist_ok=True)
    with open(p, 'w', encoding='utf-8') as f:
        json.dump(d, f, indent=1, ensure_ascii=False)


class Report:
    def __init__(self):
        self.methods, self.warn, self.dropped = [], [], []

    def m(self, s):
        if s not in self.methods:
            self.methods.append(s)

    def w(self, s):
        if s not in self.warn:
            self.warn.append(s)


# ------------------------------------------------------------------------------ locating assets
def find_root(path, tmp):
    if os.path.isfile(path):
        ex = os.path.join(tmp, 'src')
        shutil.rmtree(ex, ignore_errors=True)
        with zipfile.ZipFile(path) as z:
            z.extractall(ex)
        path = ex
    for dp, dn, fn in os.walk(path):
        if '_polymod_meta.json' in fn or ('data' in dn and ('songs' in os.listdir(os.path.join(dp, 'data')))):
            return dp
    raise SystemExit('not a V-Slice mod: no _polymod_meta.json / data/songs found')


class Assets:
    """V-Slice image roots: <root>/images and <root>/shared/images both become Psych images/."""
    def __init__(self, root):
        self.root = root
        self.dirs = [os.path.join(root, 'images'), os.path.join(root, 'shared', 'images')]

    def find(self, rel, ext='.png'):
        rel = rel.split(':')[-1]
        for d in self.dirs:
            p = os.path.join(d, rel + ext)
            if os.path.isfile(p):
                return p
            low = os.path.dirname(p)
            if os.path.isdir(low):  # case-insensitive fallback
                for f in os.listdir(low):
                    if f.lower() == os.path.basename(p).lower():
                        return os.path.join(low, f)
        return None

    def find_dir(self, rel):
        rel = rel.split(':')[-1]
        for d in self.dirs:
            p = os.path.join(d, rel)
            if os.path.isdir(p):
                return p
        return None


# ------------------------------------------------------------------------------ main converter
class VSliceConverter:
    def __init__(self, src, out, tmp='/tmp/portyou_vs'):
        os.makedirs(tmp, exist_ok=True)
        self.root = find_root(src, tmp)
        self.out = out
        self.R = Report()
        self.assets = Assets(self.root)
        meta_p = os.path.join(self.root, '_polymod_meta.json')
        self.meta = jload(meta_p) if os.path.isfile(meta_p) else {}
        self.title = self.meta.get('title') or os.path.basename(self.root)
        self.slug = slug(self.title)
        self.chars = {}        # id -> info
        self.char_sizes = {}
        self.used_images = set()
        self.empty_chars = set()
        self.hx_files = []

    def P(self, *p):
        return os.path.join(self.out, *p)

    # ------------------------------------------------------------------ top level
    def run(self):
        shutil.rmtree(self.out, ignore_errors=True)
        os.makedirs(self.out)
        songs = self.convert_songs()
        self.convert_characters()
        self.convert_stages()
        self.convert_scripts()
        if not os.path.isfile(self.P('scripts', 'portyou_vslice.lua')):
            self.write_runtime({k: dict(cx=0, cy=0, dance=2) for k in ('boyfriend', 'dad', 'gf')}, 1.0)
        self.copy_remaining_assets()
        self.write_weeks(songs)
        self.write_credits()
        self.write_report(songs)
        return self.R

    # ------------------------------------------------------------------ songs
    def convert_songs(self):
        sdir = os.path.join(self.root, 'data', 'songs')
        res = []
        for sid in sorted(os.listdir(sdir)) if os.path.isdir(sdir) else []:
            d = os.path.join(sdir, sid)
            if not os.path.isdir(d):
                continue
            charts = sorted(glob.glob(os.path.join(d, '*-chart*.json')))
            if not charts:
                continue
            res.append(self.convert_song(sid, d))
        return res

    def convert_song(self, sid, d):
        # variations (-erect etc.) share the song folder: base files first
        meta_files = {os.path.basename(f)[len(sid) + 1:-5]: f for f in glob.glob(os.path.join(d, sid + '-metadata*.json'))}
        chart_files = {os.path.basename(f)[len(sid) + 1:-5]: f for f in glob.glob(os.path.join(d, sid + '-chart*.json'))}
        base_meta = jload(meta_files.get('metadata', next(iter(meta_files.values()))))
        info = dict(id=sid, name=base_meta.get('songName', sid), diffs=[])
        for ck, cf in sorted(chart_files.items()):
            variation = ck[len('chart'):].lstrip('-')  # '' or 'erect'
            mf = meta_files.get('metadata' + ('-' + variation if variation else ''), None)
            meta = jload(mf) if mf else base_meta
            chart = jload(cf)
            psych_id = sid if not variation else '%s-%s' % (sid, variation)
            self.convert_chart(psych_id, sid, variation, meta, chart, info)
        return info

    def bpm_map(self, meta):
        tcs = meta.get('timeChanges') or [{'t': 0, 'bpm': 120, 'bt': [4, 4, 4, 4]}]
        return sorted(tcs, key=lambda x: x.get('t', 0))

    def build_sections(self, tcs, end_ms):
        """Sections follow the V-Slice measure grid; a section is cut at every time change."""
        secs = []
        t = 0.0
        i = 0
        while t < end_ms + 1:
            while i + 1 < len(tcs) and tcs[i + 1]['t'] <= t + 0.5:
                i += 1
            tc = tcs[i]
            bpm = float(tc['bpm']); beats = float((tc.get('bt') or [4])[0])
            crochet = 60000.0 / bpm
            sec_len = beats * crochet
            if i + 1 < len(tcs) and tcs[i + 1]['t'] < t + sec_len - 0.5:
                sec_len = tcs[i + 1]['t'] - t
                beats = sec_len / crochet
            secs.append(dict(start=t, end=t + sec_len, beats=beats, bpm=bpm, change=(len(secs) == 0) or abs(t - tc['t']) < 0.5))
            t += sec_len
        return secs

    def convert_chart(self, pid, sid, variation, meta, chart, info):
        play = meta.get('playData', {})
        chars = play.get('characters', {})
        tcs = self.bpm_map(meta)
        notes_by_diff = chart.get('notes', {})
        speeds = chart.get('scrollSpeed', {})
        events = chart.get('events', [])
        diffs = list(notes_by_diff.keys())
        player, opp, gf = chars.get('player', 'bf'), chars.get('opponent', 'dad'), chars.get('girlfriend', 'gf')
        for c in (player, opp, gf):
            self.chars.setdefault(c, None)
        # ---- events (shared by all difficulties of this chart file)
        evs = self.convert_events(events)
        offsets = meta.get('offsets', {})
        if offsets.get('instrumental'):
            self.R.w('instrumental offset %s ms is not applied to the chart' % offsets.get('instrumental'))
        focus = sorted([(e['t'], self.focus_char(e.get('v'))) for e in events if e.get('e') == 'FocusCamera'])
        self.R.m('chart: V-Slice 2.x -> Psych v1 (absolute lanes: player 0-3 / opponent 4-7, never flipped by sections; GF notes -> GF Sing; bpm/time changes kept)')
        for diff in diffs:
            notes = notes_by_diff[diff]
            end = max([n['t'] + n.get('l', 0) for n in notes] + [e['t'] for e in events] + [0]) + 8000
            secs = self.build_sections(tcs, end)
            sec_out = []
            for s in secs:
                must = True
                for ft, ch in focus:
                    if ft <= s['start'] + 1:
                        must = (ch == 0)
                    else:
                        break
                sec_out.append(dict(sectionNotes=[], sectionBeats=s['beats'], mustHitSection=must, gfSection=False,
                                    bpm=s['bpm'], changeBPM=bool(s['change'] and s['start'] > 0)))
            si = 0
            for n in sorted(notes, key=lambda x: (x['t'], x['d'])):
                while si + 1 < len(secs) and n['t'] >= secs[si]['end'] - 0.01:
                    si += 1
                sec = sec_out[si]
                # V-Slice: d 0-3 = player strumline, 4-7 = opponent strumline (d % 8 guards odd charts).
                # Psych 1.0 'psych_v1': data 0-3 = player, 4-7 = opponent, ABSOLUTE - it never flips with mustHitSection.
                # (The old code flipped lanes in every "opponent" section, which swapped player/opponent arrows.)
                is_player = (int(n['d']) % 8) < 4
                lane = int(n['d']) % 4
                data = lane + (0 if is_player else 4)
                kind = n.get('k') or ''
                if isinstance(kind, str) and kind.lower() in ('gf', 'gf sing', 'gfsing', 'girlfriend', 'gfnote'):
                    ptype = 'GF Sing'      # girlfriend arrows stay girlfriend's (note type built into Psych)
                else:
                    ptype = METHODS['note_kinds'].get(kind, kind)
                    if kind and kind not in METHODS['note_kinds']:
                        self.R.w('note kind "%s" kept as Psych note type (no script yet)' % kind)
                sec['sectionNotes'].append([n['t'], data, n.get('l', 0) or 0, ptype])
            speed = speeds.get(diff, speeds.get('default', 2.0))
            vocals_player = play.get('characters', {}).get('playerVocals', [player])
            chart_json = dict(song=pid, notes=sec_out, events=evs, bpm=tcs[0]['bpm'], needsVoices=True,
                              speed=speed, offset=0, player1=self.cid(player), player2=self.cid(opp), gfVersion=('gf' if gf in self.empty_chars_pre() else self.cid(gf)),
                              stage=self.stage_id(play.get('stage', 'mainStage')), format='psych_v1',
                              arrowSkin='', splashSkin='noteSplashes/noteSplashes', disableNoteRGB=False)
            fname = pid if diff.lower() == 'normal' else '%s-%s' % (pid, diff.lower())
            jsave(self.P('data', pid, fname + '.json'), chart_json)
            info['diffs'].append(diff.capitalize())
            self.R.m('difficulty file naming: %s.json = Normal, <song>-<diff>.json for the others (this mod: %s)' % (pid, diff))
        info.setdefault('psych_ids', []).append(pid)
        self.convert_audio(pid, sid, variation, play)

    @staticmethod
    def focus_char(v):
        """FocusCamera target: 0 = bf, 1 = dad, 2 = gf (int / str / dict / missing all handled)."""
        if isinstance(v, dict):
            v = v.get('char', 0)
        try:
            return int(float(v))
        except (TypeError, ValueError):
            return {'bf': 0, 'boyfriend': 0, 'player': 0, 'dad': 1, 'opponent': 1, 'gf': 2, 'girlfriend': 2}.get(str(v).lower(), 0)

    def empty_chars_pre(self):
        """Characters whose atlas is a stripped placeholder (checked before characters are converted)."""
        if not hasattr(self, '_empty_pre'):
            self._empty_pre = set()
            cdir = os.path.join(self.root, 'data', 'characters')
            for f in glob.glob(os.path.join(cdir, '*.json')):
                d = jload(f)
                if d.get('renderType') in ('animateatlas', 'atlas'):
                    ad = self.assets.find_dir(d.get('assetPath', '').split(':')[-1])
                    if ad:
                        try:
                            if A.SpriteMapReader(ad).placeholder:
                                self._empty_pre.add(os.path.basename(f)[:-5])
                        except Exception:
                            pass
        return self._empty_pre

    def cid(self, c):
        if c in METHODS['base_game_chars']:
            return c
        return c

    def stage_id(self, s):
        return s

    # ------------------------------------------------------------------ audio
    def convert_audio(self, pid, sid, variation, play):
        src = os.path.join(self.root, 'songs', sid)
        dst = self.P('songs', pid)
        os.makedirs(dst, exist_ok=True)
        if not os.path.isdir(src):
            self.R.w('songs/%s missing in the mod (add the audio files for the mod owner)' % sid)
            return
        suffix = '-' + variation if variation else ''
        inst = [f for f in (('Inst%s.ogg' % suffix), 'Inst.ogg') if os.path.isfile(os.path.join(src, f))]
        if inst:
            shutil.copy(os.path.join(src, inst[0]), os.path.join(dst, 'Inst.ogg'))
        else:
            self.R.w('no Inst.ogg for %s' % pid)
        ch = play.get('characters', {})
        groups = {'Player': ch.get('playerVocals') or [], 'Opponent': ch.get('opponentVocals') or []}
        for gname, names in groups.items():
            files = []
            for n in names:
                for cand in ('Voices-%s%s.ogg' % (n, suffix), 'Voices-%s.ogg' % n):
                    if os.path.isfile(os.path.join(src, cand)):
                        files.append(os.path.join(src, cand)); break
            if not files:
                continue
            out = os.path.join(dst, 'Voices-%s.ogg' % gname)
            if len(files) == 1:
                shutil.copy(files[0], out)
            else:
                cmd = ['ffmpeg', '-y', '-loglevel', 'error']
                for f in files:
                    cmd += ['-i', f]
                cmd += ['-filter_complex', '%samix=inputs=%d:normalize=0' % (''.join('[%d:a]' % i for i in range(len(files))), len(files)), '-c:a', 'libvorbis', out]
                subprocess.run(cmd, check=False)
            self.R.m('vocals: every file of a group (%s) merged into Voices-%s.ogg (Psych 1.0 loads Player/Opponent vocals)' % (gname.lower(), gname))
        if not any(os.path.isfile(os.path.join(dst, 'Voices-%s.ogg' % g)) for g in groups):
            lone = os.path.join(src, 'Voices%s.ogg' % suffix)
            if os.path.isfile(lone):
                shutil.copy(lone, os.path.join(dst, 'Voices.ogg'))

    # ------------------------------------------------------------------ events
    def convert_events(self, events):
        out = {}
        ev_map = METHODS['events']
        for e in sorted(events, key=lambda x: x['t']):
            kind, v = e['e'], e.get('v') or {}
            m = ev_map.get(kind)
            if m is None:
                self.R.w('event "%s" has no method yet (kept as a custom event, runs nothing)' % kind)
                row = [kind, self.flat(v), '']
            elif m['kind'] == 'psych':
                if kind == 'PlayAnimation':
                    row = ['Play Animation', str(v.get('anim', 'idle')), self.target(v.get('target', 'boyfriend'))]
                elif kind == 'AddCameraZoom':
                    row = ['Add Camera Zoom', str(v.get('game', 0.015)), str(v.get('hud', 0.03))]
                else:
                    row = [m['name'], '', '']
                self.R.m('event %s -> Psych "%s"' % (kind, m['name']))
            else:
                row = [m['name'], self.flat(v), '']
                self.R.m('event %s -> runtime %s (scripts/portyou_vslice.lua)' % (kind, m['name']))
            out.setdefault(e['t'], []).append(row)
        return [[t, rows] for t, rows in sorted(out.items())]

    @staticmethod
    def target(t):
        t = str(t).lower()
        if t in ('dad', 'opponent', '1'):
            return 'dad'
        if t in ('gf', 'girlfriend', '2'):
            return 'gf'
        return 'bf'

    @staticmethod
    def flat(v):
        parts = []
        for k, x in v.items():
            if isinstance(x, bool):
                x = '1' if x else '0'
            elif isinstance(x, float) and x == int(x):
                x = int(x)
            parts.append('%s=%s' % (k, str(x).replace(';', ',')))
        return ';'.join(parts)

    # ------------------------------------------------------------------ characters
    def convert_characters(self):
        cdir = os.path.join(self.root, 'data', 'characters')
        for cid in list(self.chars):
            p = os.path.join(cdir, cid + '.json')
            if not os.path.isfile(p):
                self.R.w('character "%s" is a base-game character (not inside the mod); Psych uses its own "%s" if it exists' % (cid, cid))
                continue
            self.chars[cid] = self.convert_character(cid, jload(p))

    def icon_color(self, icon_id):
        p = self.assets.find('icons/icon-' + icon_id) or self.assets.find('icons/' + icon_id)
        if p:
            im = Image.open(p).convert('RGBA')
            w = im.width // 2 if im.width >= im.height * 2 else im.width
            im = im.crop((0, 0, w, im.height)).resize((32, 32))
            px = [q for q in im.getdata() if q[3] > 200]
            if px:
                best = max(px, key=lambda q: colorsys.rgb_to_hsv(q[0] / 255, q[1] / 255, q[2] / 255)[1] * 0.6 +
                           colorsys.rgb_to_hsv(q[0] / 255, q[1] / 255, q[2] / 255)[2] * 0.4)
                n = [q for q in px if sum(abs(a - b) for a, b in zip(q[:3], best[:3])) < 90]
                return [int(sum(q[i] for q in n) / len(n)) for i in range(3)]
        fb = METHODS['healthbar_fallback']
        return fb.get(icon_id, fb['default'])

    def convert_character(self, cid, d):
        rt = d.get('renderType', 'sparrow')
        asset = d.get('assetPath', 'characters/' + cid).split(':')[-1]
        anims_in = d.get('animations', [])
        out_name = cid
        image = 'characters/' + os.path.basename(asset)
        atlas_dir = self.assets.find_dir(asset) if rt in ('animateatlas', 'atlas') else None
        frame_size = None
        if rt in ('animateatlas', 'atlas') or atlas_dir:
            if atlas_dir is None:
                self.R.w('character %s: atlas folder missing' % cid); return None
            reader = A.SpriteMapReader(atlas_dir)
            if reader.placeholder or not reader.sprites:
                self.R.w('character "%s": its spritemap image is a 1x1 placeholder (the real art is in the base game) -> character dropped, slot hidden' % cid)
                self.R.m('stripped atlas detected -> girlfriend/slot hidden instead of broken sprite')
                self.empty_chars.add(cid)
                return dict(empty=True, data=d)
            groups, seen = [], set()
            for a in anims_in:
                pre = a['prefix']
                if pre.lower() in seen:
                    continue
                seen.add(pre.lower())
                r = reader.render_label(pre, hint=AI.label_hint if AI.URL else None)
                if r is None:
                    self.R.w('character %s: label "%s" not found in the atlas' % (cid, pre)); continue
                groups.append((pre, r[0]))
            png = self.P('images', 'characters', cid + '.png'); xml = self.P('images', 'characters', cid + '.xml')
            A.pack_sparrow(groups, png, xml)
            image = 'characters/' + cid
            self.R.m('spritemap (Adobe Animate atlas) -> rendered with the main atlas engine -> Sparrow sheet + xml')
            xml_path = xml
        else:
            xml_path = self.assets.find(asset, '.xml')
            png = self.assets.find(asset, '.png')
            if png is None or xml_path is None:
                self.R.w('character %s: image/xml "%s" not found' % (cid, asset)); return None
            for ext, sp in (('.png', png), ('.xml', xml_path)):
                dst = self.P('images', 'characters', os.path.basename(asset) + ext)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy(sp, dst)
            if rt == 'multisparrow':
                self.R.w('character %s: multisparrow has extra sheets that are not merged yet' % cid)
        scale = float(d.get('scale', 1))
        hi = d.get('healthIcon', {}) or {}
        icon_id = hi.get('id', cid)
        anims = []
        for a in anims_in:
            off = a.get('offsets') or [0, 0]
            anims.append(dict(anim=a['name'], name=a['prefix'], fps=int(a.get('frameRate', 24)), loop=bool(a.get('looped', False)),
                              indices=a.get('frameIndices') or [], offsets=[-off[0], -off[1]]))
        idle = next((a for a in anims_in if a['name'] in ('idle', 'danceLeft')), anims_in[0] if anims_in else None)
        fs = A.sparrow_first_frame_size(xml_path, idle['prefix']) if idle and xml_path else None
        self.char_sizes[cid] = (fs[0] * scale, fs[1] * scale) if fs else (0, 0)
        info = dict(psych=dict(animations=anims, vocals_file='', no_antialiasing=bool(d.get('isPixel', False)), image=image,
                               position=list(d.get('offsets', [0, 0])), healthicon=icon_id, flip_x=bool(d.get('flipX', False)),
                               healthbar_colors=self.icon_color(icon_id), camera_position=list(d.get('cameraOffsets', [0, 0])),
                               sing_duration=float(d.get('singTime', 4)), scale=scale),
                    dance=int(d.get('danceEvery', 2)), cam=list(d.get('cameraOffsets', [0, 0])), icon=icon_id)
        jsave(self.P('characters', cid + '.json'), info['psych'])
        self.R.m('character json: V-Slice anim offsets negated -> Psych offsets; position=offsets; flipX kept; healthbar colour measured from the icon')
        return info

    # ------------------------------------------------------------------ stages
    def convert_stages(self):
        sdir = os.path.join(self.root, 'data', 'stages')
        used = set()
        for f in glob.glob(os.path.join(self.root, 'data', 'songs', '*', '*-metadata*.json')):
            used.add(jload(f).get('playData', {}).get('stage', 'mainStage'))
        for sid in sorted(used):
            p = os.path.join(sdir, sid + '.json')
            if not os.path.isfile(p):
                self.R.w('stage "%s" is a base-game stage (not in the mod)' % sid)
                continue
            self.convert_stage(sid, jload(p))
        used_ev = set()
        for f in glob.glob(os.path.join(self.root, 'data', 'songs', '*', '*-chart*.json')):
            used_ev |= {e['e'] for e in jload(f).get('events', [])}
        for h in glob.glob(os.path.join(self.root, 'scripts', 'events', '*.hxc')):
            src = open(h, encoding='utf-8', errors='ignore').read()
            m = re.search(r'super\(\s*"([^"]+)"', src)
            kind = m.group(1) if m else os.path.basename(h)[:-4]
            if kind not in used_ev:
                self.R.dropped.append(os.path.basename(h))
            elif kind not in METHODS['events']:
                self.hx_files.append((h, 'event', kind))
        if self.R.dropped:
            self.R.w('%d custom event scripts are not used by any chart, so they were not ported: %s' % (len(self.R.dropped), ', '.join(self.R.dropped)))
        hxc = glob.glob(os.path.join(self.root, 'scripts', 'stages', '*.hxc'))
        for h in hxc:
            self.hx_files.append((h, 'stage', None))
        # every other Haxe script of the mod (modules, song scripts, characters) is converted too
        seen = {f[0] for f in self.hx_files}
        evdir = os.path.join(self.root, 'scripts', 'events')
        for h in glob.glob(os.path.join(self.root, 'scripts', '**', '*.hx*'), recursive=True):
            if h in seen or os.path.dirname(h) == evdir or os.path.dirname(h).endswith(os.sep + 'stages'):
                continue
            self.hx_files.append((h, 'script', None))

    def convert_scripts(self):
        """Haxe -> Lua for every script that is actually used. Whatever cannot be converted is moved out of the mod into
        <out>_unconverted/ with a multilingual report (only created when something failed)."""
        if not self.hx_files:
            return
        n_ok, fails = hx2lua.convert_many(self.hx_files, self.out, self.out.rstrip('/\\') + '_unconverted')
        self.R.m('haxe scripts -> lua (per function, rule table in methods.json, optional local AI): %d file(s) converted' % n_ok)
        for f, fn, why, _ in fails:
            self.R.w('could not convert %s :: %s (%s) -> see %s_unconverted/' % (f, fn, why, os.path.basename(self.out.rstrip('/\\'))))

    def convert_stage(self, sid, d):
        zoom = float(d.get('cameraZoom', 1.0))
        chars = d.get('characters', {})
        slot_names = {'bf': 'boyfriend', 'dad': 'dad', 'gf': 'gf'}
        # which character ids stand in each slot (first song using the stage)
        slot_char = {}
        for f in glob.glob(os.path.join(self.root, 'data', 'songs', '*', '*-metadata*.json')):
            m = jload(f)
            if m.get('playData', {}).get('stage') == sid:
                c = m['playData'].get('characters', {})
                slot_char = {'bf': c.get('player'), 'dad': c.get('opponent'), 'gf': c.get('girlfriend')}
                break

        def top_left(slot):
            ch = chars.get(slot, {})
            x, y = ch.get('position', [0, 0])
            cid = slot_char.get(slot)
            w, h = self.char_sizes.get(cid, (0, 0))
            return [round(x - w / 2, 2), round(y - h, 2)]

        hide_gf = (slot_char.get('gf') in self.empty_chars) or not slot_char.get('gf')
        slot_data = {}
        for slot, name in slot_names.items():
            c = chars.get(slot, {})
            cid = slot_char.get(slot)
            info = self.chars.get(cid) or {}
            cam = c.get('cameraOffsets', [0, 0])
            ccam = info.get('cam', [0, 0]) if isinstance(info, dict) else [0, 0]
            slot_data[name] = dict(cx=cam[0] + ccam[0], cy=cam[1] + ccam[1], dance=(info.get('dance', 2) if isinstance(info, dict) else 2))
        stage_json = dict(directory='', defaultZoom=zoom, isPixelStage=False, boyfriend=top_left('bf'), girlfriend=top_left('gf'),
                          opponent=top_left('dad'), hide_girlfriend=bool(hide_gf), camera_boyfriend=[0, 0], camera_opponent=[0, 0],
                          camera_girlfriend=[0, 0], camera_speed=1)
        jsave(self.P('stages', sid + '.json'), stage_json)
        self.R.m('stage json: V-Slice character position is the feet/bottom-centre -> Psych top-left (minus half width, minus height of the idle frame)')
        # ---- lua: props
        props = d.get('props', [])
        lines = ['-- PortYou Studio: stage "%s" (generated from V-Slice stage json)' % sid, 'function onCreate()']
        zs = sorted(c.get('zIndex', 0) for c in chars.values()) or [0]
        pending_order = []
        for i, p in sorted(enumerate(props), key=lambda ip: ip[1].get('zIndex', 0)):
            tag = 'p%d' % i
            img = p.get('assetPath', '').split(':')[-1]
            if not img:
                continue
            if self.assets.find(img) is None:
                self.R.w('stage prop image "%s" not found in the mod' % img); continue
            self.used_images.add(img)
            anims = p.get('animations') or []
            pos = p.get('position', [0, 0])
            if anims:
                lines.append("\tmakeAnimatedLuaSprite(%s, %s, %s, %s)" % (lua_str(tag), lua_str(img), pos[0], pos[1]))
                for a in anims:
                    fr = a.get('frameIndices') or []
                    if fr:
                        lines.append("\taddAnimationByIndices(%s, %s, %s, '%s', %s)" % (lua_str(tag), lua_str(a['name']), lua_str(a['prefix']), ','.join(map(str, fr)), a.get('frameRate', 24)))
                    else:
                        lines.append("\taddAnimationByPrefix(%s, %s, %s, %s, %s)" % (lua_str(tag), lua_str(a['name']), lua_str(a['prefix']), a.get('frameRate', 24), 'true' if a.get('looped') else 'false'))
                if p.get('startingAnimation'):
                    lines.append("\tplayAnim(%s, %s, true)" % (lua_str(tag), lua_str(p['startingAnimation'])))
            else:
                lines.append("\tmakeLuaSprite(%s, %s, %s, %s)" % (lua_str(tag), lua_str(img), pos[0], pos[1]))
            sc = p.get('scale', [1, 1])
            if sc != [1, 1]:
                lines.append("\tscaleObject(%s, %s, %s, true)" % (lua_str(tag), sc[0], sc[1]))
            scr = p.get('scroll', [1, 1])
            lines.append("\tsetScrollFactor(%s, %s, %s)" % (lua_str(tag), scr[0], scr[1]))
            if p.get('alpha', 1) != 1:
                lines.append("\tsetProperty(%s..'.alpha', %s)" % (lua_str(tag), p['alpha']))
            if p.get('angle'):
                lines.append("\tsetProperty(%s..'.angle', %s)" % (lua_str(tag), p['angle']))
            if p.get('flipX'):
                lines.append("\tsetProperty(%s..'.flipX', true)" % lua_str(tag))
            if p.get('flipY'):
                lines.append("\tsetProperty(%s..'.flipY', true)" % lua_str(tag))
            col = (p.get('color') or '#FFFFFF').lstrip('#')[-6:]
            if col.upper() != 'FFFFFF':
                lines.append("\tsetProperty(%s..'.color', getColorFromHex(%s))" % (lua_str(tag), lua_str(col)))
            if p.get('blend'):
                lines.append("\tsetBlendMode(%s, %s)" % (lua_str(tag), lua_str(str(p['blend']).lower())))
            if p.get('isPixel'):
                lines.append("\tsetProperty(%s..'.antialiasing', false)" % lua_str(tag))
            z = p.get('zIndex', 0)
            front = z > max(zs)
            lines.append("\taddLuaSprite(%s, %s)" % (lua_str(tag), 'true' if front else 'false'))
            if min(zs) <= z <= max(zs):
                pending_order.append((tag, z))
        lines.append('end')
        if pending_order:
            lines.append('function onCreatePost()')
            order = sorted([('gfGroup', chars.get('gf', {}).get('zIndex', 100)), ('dadGroup', chars.get('dad', {}).get('zIndex', 200)),
                            ('boyfriendGroup', chars.get('bf', {}).get('zIndex', 300))], key=lambda x: x[1])
            for tag, z in pending_order:
                grp = next((g for g, gz in order if gz > z), None)
                if grp:
                    lines.append("\tsetObjectOrder(%s, getObjectOrder(%s))" % (lua_str(tag), lua_str(grp)))
            lines.append('end')
        dance = [(('p%d' % i), p) for i, p in enumerate(props) if p.get('animations') and p.get('danceEvery')]
        if dance:
            lines.append('function onBeatHit()')
            for tag, p in dance:
                names = [a['name'] for a in p['animations']]
                if 'danceLeft' in names and 'danceRight' in names:
                    lines.append("\tif curBeat %% %d == 0 then playAnim(%s, (curBeat / %d) %% 2 == 0 and 'danceLeft' or 'danceRight', true) end" % (p['danceEvery'], lua_str(tag), p['danceEvery']))
                else:
                    lines.append("\tif curBeat %% %d == 0 then playAnim(%s, %s, true) end" % (p['danceEvery'], lua_str(tag), lua_str(names[0])))
            lines.append('end')
        os.makedirs(self.P('stages'), exist_ok=True)
        open(self.P('stages', sid + '.lua'), 'w', encoding='utf-8').write('\n'.join(lines) + '\n')
        self.R.m('stage props -> Lua sprites (position, scale, scroll, alpha, colour, blend, flip, animations, dance); z-index -> behind/front of the characters')
        self.write_runtime(slot_data, zoom)

    def write_runtime(self, slot, zoom):
        pal = METHODS['extra_events_palette']
        data = 'local STAGE_ZOOM = %s\nlocal PALETTE = {%s}\nlocal SLOT = {\n%s}\n' % (
            zoom, ', '.join("'%s'" % c for c in pal),
            ''.join("\t%s = {cx = %s, cy = %s, dance = %s},\n" % (k, v['cx'], v['cy'], v['dance']) for k, v in slot.items()))
        tpl = open(os.path.join(HERE, 'vslice_runtime.lua'), encoding='utf-8').read().replace('--[[DATA]]', data)
        os.makedirs(self.P('scripts'), exist_ok=True)
        open(self.P('scripts', 'portyou_vslice.lua'), 'w', encoding='utf-8').write(tpl)

    # ------------------------------------------------------------------ remaining assets
    def copy_remaining_assets(self):
        skip = set(METHODS['skip_dirs'])
        atlas_dirs = set()
        for d in self.assets.dirs:
            for dp, dn, fn in os.walk(d):
                if 'Animation.json' in fn:
                    atlas_dirs.add(dp)
        n = 0
        for d in self.assets.dirs:
            for dp, dn, fn in os.walk(d):
                rel = os.path.relpath(dp, d)
                top = rel.split(os.sep)[0]
                if top in skip or any(dp.startswith(a) for a in atlas_dirs):
                    continue
                for f in fn:
                    dst = self.P('images', rel if rel != '.' else '', f)
                    if os.path.isfile(dst):
                        continue
                    os.makedirs(os.path.dirname(dst), exist_ok=True)
                    shutil.copy(os.path.join(dp, f), dst)
                    n += 1
        for sub in ('sounds', 'music', 'videos'):
            for base in (os.path.join(self.root, sub), os.path.join(self.root, 'shared', sub)):
                if os.path.isdir(base):
                    shutil.copytree(base, self.P(sub), dirs_exist_ok=True)
        self.R.m('assets: images/ + shared/images/ merged into Psych images/ (freeplay pixel icons and story-menu art are dropped/converted separately)')
        # character icons: Psych wants images/icons/icon-<id>.png (already copied above)

    # ------------------------------------------------------------------ weeks
    def write_weeks(self, songs):
        ldir = os.path.join(self.root, 'data', 'levels')
        levels = [jload(f) for f in sorted(glob.glob(os.path.join(ldir, '*.json')))] if os.path.isdir(ldir) else []
        story = None
        for lv in levels:
            if lv.get('visible', True) and self.story_assets_ok(lv):
                story = lv; break
        wname = self.slug  # week file = mod name (never a fixed name)
        song_rows = []
        for s in songs:
            for pid in s.get('psych_ids', [s['id']]):
                cid = self.first_icon(s)
                col = (self.chars.get(self.opp_of(s)) or {}).get('psych', {}).get('healthbar_colors', [161, 161, 161])
                song_rows.append([pid, cid, col])
        diffs = []
        for s in songs:
            for d in s['diffs']:
                if d not in diffs:
                    diffs.append(d)
        week = dict(songs=song_rows, weekCharacters=['', 'bf', 'gf'], weekBackground='', weekBefore='tutorial', storyName=self.title,
                    weekName=self.title, startUnlocked=True, hideStoryMode=True, hideFreeplay=False, difficulties=', '.join(diffs) or 'Normal')
        if story:
            self.convert_story(story, week, wname)
        else:
            self.R.m('week: freeplay only (no usable classic story assets; custom story UI is deleted)')
        jsave(self.P('weeks', wname + '.json'), week)
        self.R.m('week file named after the mod (%s.json) so two mods never collide' % wname)

    def story_assets_ok(self, lv):
        props = lv.get('props', [])
        if not props:
            return False
        return all(self.assets.find(p.get('assetPath', '')) for p in props if p.get('assetPath'))

    def convert_story(self, lv, week, wname):
        names = ['', 'bf', 'gf']
        for i, p in enumerate(lv.get('props', [])[:3]):
            slot_id = '%s-%s' % (wname, ['dad', 'bf', 'gf'][i])
            src = p['assetPath']
            png, xml = self.assets.find(src), self.assets.find(src, '.xml')
            dst = self.P('images', 'menucharacters', slot_id)
            os.makedirs(os.path.dirname(dst), exist_ok=True)
            shutil.copy(png, dst + '.png')
            if xml:
                shutil.copy(xml, dst + '.xml')
            anims = p.get('animations') or [{}]
            idle = next((a for a in anims if a.get('name') in ('idle', 'danceLeft')), anims[0])
            conf = next((a for a in anims if a.get('name') == 'confirm'), None)
            jsave(self.P('images', 'menucharacters', slot_id + '.json'), dict(image='menucharacters/' + slot_id, scale=p.get('scale', 1),
                  position=p.get('offsets', [0, 0]), idle_anim=idle.get('prefix', 'idle'), confirm_anim=(conf or {}).get('prefix', idle.get('prefix', 'idle')), flipX=False))
            names[i] = slot_id
        week['weekCharacters'] = names
        week['hideStoryMode'] = False
        week['storyName'] = lv.get('name', self.title)
        bg = lv.get('background', '')
        if isinstance(bg, str) and bg.startswith('#'):
            rgb = tuple(int(bg[i:i + 2], 16) for i in (1, 3, 5))
            os.makedirs(self.P('images', 'menubackgrounds'), exist_ok=True)
            Image.new('RGB', (1280, 400), rgb).save(self.P('images', 'menubackgrounds', 'menu_%s.png' % wname))
            week['weekBackground'] = wname
        t = lv.get('titleAsset')
        tp = self.assets.find(t) if t else None
        if tp:
            os.makedirs(self.P('images', 'storymenu'), exist_ok=True)
            shutil.copy(tp, self.P('images', 'storymenu', wname + '.png'))
        self.R.m('story mode: classic story assets found -> menucharacters + week image + background colour PNG')

    def first_icon(self, s):
        sid = s['id']
        for f in glob.glob(os.path.join(self.root, 'data', 'songs', sid, '*-metadata.json')):
            op = jload(f).get('playData', {}).get('characters', {}).get('opponent')
            c = self.chars.get(op)
            return (c or {}).get('icon', op or 'face')
        return 'face'

    def opp_of(self, s):
        for f in glob.glob(os.path.join(self.root, 'data', 'songs', s['id'], '*-metadata.json')):
            return jload(f).get('playData', {}).get('characters', {}).get('opponent')

    # ------------------------------------------------------------------ credits / report
    def write_credits(self):
        C.write(self.out, self.title, os.path.join(HERE, '..', '..', 'app', 'src', 'main', 'assets', 'converter', 'pack.png'))
        self.R.m('credits: pack.json (English + Portuguese only) + pack.png + scripts/portyou_credit.lua ("Port You Studio") added')

    def write_report(self, songs):
        lines = ['# PortYou Studio - conversion report', '', 'Mod: %s (author in meta: %s)' % (self.title, self.meta.get('author', '?')), '',
                 '## Methods used', ''] + ['- ' + m for m in self.R.methods] + ['', '## Warnings / things for the mod owner', ''] + \
                ['- ' + w for w in self.R.warn] + ['']
        open(self.P('CONVERSION_REPORT.md'), 'w', encoding='utf-8').write('\n'.join(lines))


def main(argv):
    if len(argv) < 3:
        print(__doc__); return 1
    c = VSliceConverter(argv[1], argv[2])
    r = c.run()
    print('methods:', len(r.methods), 'warnings:', len(r.warn))
    for w in r.warn:
        print(' !', w)
    return 0
