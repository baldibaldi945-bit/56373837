-- PortYou Studio: FNMM runtime (generated). Executes every Funky Maker action inside Psych Engine.
local CAMS = { --[[CAMS]] }
--[[CHAROBJ]]
local OBJS = {
--[[OBJS]]
}
local SPRS = {
--[[SPRS]]
}
local EASE = {default='sineInOut', linear='linear', cubic='cubeInOut', expo='expoInOut', back='backInOut',
	elastic='elasticInOut', bounce='bounceInOut', circ='circInOut', slow='sineInOut'}
local chartObj = {}   -- strumLine -> overlay tag taking over its notes
local cur = {}        -- idx -> {sprite=name, anim=k}
local flashN = 0

local function P(v1)
	local t = {}
	for kv in string.gmatch(v1 or '', '[^;]+') do
		local k, v = string.match(kv, '^([^=]+)=(.*)$')
		if k then t[k] = v end
	end
	return t
end
local function secs(t, key, unitKey)
	local d = tonumber(t[key]) or 0
	if (t[unitKey] or 'seconds') == 'beats' then d = d * (crochet / 1000) end
	return d
end
local function objChar(idx)
	if idx == CHAR_OBJ[0] then return 'boyfriend' end
	if idx == CHAR_OBJ[1] then return 'dad' end
	return nil
end
local function tagOf(idx) return 'fnmm' .. idx end
local ZOOM_K = 0.7   -- stage defaultZoom = FNMM camera scale * 0.7 (see stage json), so every zoom value uses the same factor
local FRONT_FROM = math.huge
for _, ci in pairs(CHAR_OBJ) do if ci >= 0 and ci < FRONT_FROM then FRONT_FROM = ci end end
local function clampZoom(z) if z < 0.05 then return 0.05 end return z end
local function clamp01(v) if v < 0 then return 0 end if v > 1 then return 1 end return v end

local function setupAnim(tag, a, idx)
	loadGraphic(tag, a.img, a.fw, a.fh)
	if a.frames > 1 then
		local fr = {}
		for i = 0, a.frames - 1 do fr[#fr + 1] = i end
		addAnimation(tag, 'a', fr, math.floor(a.fps + 0.5), a.loop)
		objectPlayAnimation(tag, 'a', true)
	end
end

local function place(tag, o, a, scale)
	local sx = tonumber(o.scaleX) or scale
	local sy = tonumber(o.scaleY) or scale
	scaleObject(tag, sx, sy, true)
	setProperty(tag .. '.x', o.cx - (a.fw * sx) / 2)
	setProperty(tag .. '.y', o.cy - (a.fh * sy) / 2)
end

function onCreate()
	for _, o in ipairs(OBJS) do
		local tag = tagOf(o.idx)
		local a = o.anims[1]
		makeLuaSprite(tag, a.img, 0, 0)
		setupAnim(tag, a, o.idx)
		place(tag, o, a, o.scale)
		setScrollFactor(tag, tonumber(o.scrollX) or 1, tonumber(o.scrollY) or 1)
		setProperty(tag .. '.alpha', clamp01(tonumber(o.alpha) or 1))
		setProperty(tag .. '.angle', tonumber(o.angle) or 0)
		if o.color then setProperty(tag .. '.color', getColorFromHex(o.color)) end
		setProperty(tag .. '.visible', o.visible)
		if o.fixed then setObjectCamera(tag, 'camOther') end
		addLuaSprite(tag, o.idx > FRONT_FROM)
		cur[o.idx] = {sprite = o.spr, anim = 1, o = o}
	end
end

function onCreatePost()
	if CHAR_OBJ[1] == -1 then setProperty('dad.visible', false) end
	local c1 = CAMS[1]
	if c1 then
		setProperty('isCameraOnForcedPos', true)
		setProperty('camFollow.x', c1[1]); setProperty('camFollow.y', c1[2])
		setProperty('camGame.scroll.x', c1[1] - screenWidth / 2); setProperty('camGame.scroll.y', c1[2] - screenHeight / 2)
		local z = clampZoom((c1[3] or 1) * ZOOM_K)
		setProperty('defaultCamZoom', z); setProperty('camGame.zoom', z)
	end
	setProperty('camGame.alpha', 1); setProperty('camHUD.alpha', 1)
end

local function overlayFor(idx, sprName)
	-- used when a character object gets a different sprite (ObjectSpriteSet): show an overlay at the character position
	local tag = 'fnmmov' .. idx .. sprName
	if not luaSpriteExists(tag) then
		local s = SPRS[sprName]; if not s then return nil end
		local a = s[1]
		makeLuaSprite(tag, a.img, 0, 0)
		setupAnim(tag, a, idx)
		local c = objChar(idx)
		local ch = c or 'boyfriend'
		setProperty(tag .. '.x', getMidpointX(ch) - a.fw / 2)
		setProperty(tag .. '.y', getMidpointY(ch) - a.fh / 2)
		addLuaSprite(tag, true)
		setProperty(tag .. '.visible', false)
	end
	return tag
end

local function handle(name, v1, v2)
	local t = P(v1)
	if name == 'ScreenFlash' then
		flashN = flashN + 1
		local tag = 'fnmmFlash' .. flashN
		local r, g, b = tonumber(t.color_r) or 255, tonumber(t.color_g) or 255, tonumber(t.color_b) or 255
		makeLuaSprite(tag, nil, 0, 0)
		makeGraphic(tag, screenWidth, screenHeight, string.format('%02X%02X%02X', r, g, b))
		setObjectCamera(tag, 'camOther')
		setProperty(tag .. '.alpha', clamp01(tonumber(t.alpha) or 1))
		addLuaSprite(tag, true)
		doTweenAlpha('fnmmFlashT' .. flashN, tag, 0, secs(t, 'duration', 'timeUnit'), 'linear')
	elseif name == 'CameraShake' then
		cameraShake('camGame', (tonumber(t.strength) or 5) * 0.001, secs(t, 'delay', 'timeUnit') * (tonumber(t.shakes) or 1) + 0.1)
	elseif name == 'CameraSet' then
		if t.mode == 'auto' then
			setProperty('isCameraOnForcedPos', false)
			triggerEvent('Camera Follow Pos', '', '')
		else
			local c = CAMS[(tonumber(t.target) or 0) + 1] or CAMS[1]
			setProperty('isCameraOnForcedPos', true)
			local d = secs(t, 'transitionTime', 'transitionTimeUnit')
			local e = EASE[t.easingType or 'default'] or 'sineInOut'
			if c[3] then setProperty('defaultCamZoom', clampZoom(c[3] * ZOOM_K)) end
			if d <= 0 then
				setProperty('camFollow.x', c[1]); setProperty('camFollow.y', c[2])
			else
				doTweenX('fnmmCamX', 'camFollow', c[1], d, e)
				doTweenY('fnmmCamY', 'camFollow', c[2], d, e)
			end
		end
	elseif name == 'CameraZoom' then
		local d = secs(t, 'transitionTime', 'transitionTimeUnit')
		local z = clampZoom((tonumber(t.value) or 1) * ZOOM_K)
		if d <= 0 then setProperty('camGame.zoom', z); setProperty('defaultCamZoom', z)
		else
			setProperty('defaultCamZoom', z)
			doTweenZoom('fnmmZoom', 'camGame', z, d, EASE[t.easingType or 'default'] or 'sineInOut')
		end
	elseif name == 'GUI' then
		setProperty('camHUD.visible', t.visible ~= '0')
	elseif name == 'BarIconChange' then
		local ic = (t.target == '1') and 'iconP1' or 'iconP2'
		callMethod(ic .. '.changeIcon', {'fnmm-' .. (t.sprite or '')})
	elseif name == 'PlayerHealth' then
		local h, v, mn = getProperty('health'), (tonumber(t.value) or 0) / 50, (tonumber(t.minHealth) or 0) / 50
		if t.operation == 'add' then h = h + v elseif t.operation == 'remove' then h = h - v else h = v end
		if h < mn then h = mn end
		setProperty('health', h)
	elseif name == 'ObjectVisibilitySet' then
		local idx = tonumber(t.object)
		local vis = t.value == '1'
		local c = objChar(idx)
		if c then setProperty(c .. '.visible', vis) else setProperty(tagOf(idx) .. '.visible', vis) end
	elseif name == 'ObjectOpacitySet' then
		local idx = tonumber(t.object)
		local tag = objChar(idx) or tagOf(idx)
		local d = secs(t, 'transitionTime', 'transitionTimeUnit')
		local v = tonumber(t.value) or 1
		if d <= 0 then setProperty(tag .. '.alpha', v) else doTweenAlpha('fnmmOp' .. idx, tag, v, d, 'linear') end
	elseif name == 'ObjectBlendColor' then
		local idx = tonumber(t.object)
		local tag = objChar(idx) or tagOf(idx)
		local hex = string.format('%02X%02X%02X', tonumber(t.color_r) or 255, tonumber(t.color_g) or 255, tonumber(t.color_b) or 255)
		setProperty(tag .. '.color', getColorFromHex(hex))
	elseif name == 'ObjectPositionSet' then
		local idx = tonumber(t.object)
		local o = cur[idx] and cur[idx].o
		local tag = objChar(idx) or tagOf(idx)
		local x, y = tonumber(t['transform.x']), tonumber(t['transform.y'])
		if x and y then
			local a = o and o.anims[1]
			local nx = a and (x - a.fw * (o.scaleX or o.scale) / 2) or x
			local ny = a and (y - a.fh * (o.scaleY or o.scale) / 2) or y
			local d = secs(t, 'transitionTime', 'transitionTimeUnit')
			if d <= 0 then setProperty(tag .. '.x', nx); setProperty(tag .. '.y', ny)
			else
				local e = EASE[t.easingType or 'default'] or 'sineInOut'
				doTweenX('fnmmPX' .. idx, tag, nx, d, e); doTweenY('fnmmPY' .. idx, tag, ny, d, e)
			end
		end
	elseif name == 'ObjectSpriteSet' then
		local idx = tonumber(t.object)
		local c = objChar(idx)
		if c then
			local tag = overlayFor(idx, t.sprite or '')
			if tag then setProperty(c .. '.visible', false); setProperty(tag .. '.visible', true) end
		elseif SPRS[t.sprite] then
			local a = SPRS[t.sprite][1]
			local o = cur[idx] and cur[idx].o
			setupAnim(tagOf(idx), a, idx)
			if o then place(tagOf(idx), o, a, o.scale) end
			cur[idx].sprite = t.sprite; cur[idx].anim = 1
		end
	elseif name == 'ObjectAnimationSet' then
		local idx = tonumber(t.object)
		local k = (tonumber(t.anim) or 0) + 1
		local c = objChar(idx)
		if c then
			local names = {'idle', 'singLEFT', 'singDOWN', 'singUP', 'singRIGHT', 'miss', 'special'}
			if names[k] then
				setProperty(c .. '.skipDance', k > 1)
				characterPlayAnim(c, names[k], true)
			end
		else
			local s = cur[idx] and SPRS[cur[idx].sprite]
			if s and s[k] then
				setupAnim(tagOf(idx), s[k], idx)
				if cur[idx].o then place(tagOf(idx), cur[idx].o, s[k], cur[idx].o.scale) end
				cur[idx].anim = k
			end
		end
	elseif name == 'ObjectChartChange' then
		local sl = tonumber(t.strumLine) or -1
		chartObj[sl] = (sl >= 0) and (tonumber(t.object) or nil) or nil
	end
end

function onEvent(name, v1, v2)
	local ok, err = pcall(handle, name, v1, v2)
	if not ok then debugPrint('PortYou FNMM event ' .. tostring(name) .. ': ' .. tostring(err)) end
end

local DIRN = {[0] = 2, [1] = 3, [2] = 4, [3] = 5}  -- note column -> animation index+1 (left, down, up, right)
local function hit(player, dir)
	local sl = player and 0 or 1
	local idx = chartObj[sl]
	if idx and not objChar(idx) then
		local s = cur[idx] and SPRS[cur[idx].sprite]
		local k = DIRN[dir]
		if s and s[k] then setupAnim(tagOf(idx), s[k], idx) end
	end
end
function goodNoteHit(id, dir, nt, sus) hit(true, dir) end
function opponentNoteHit(id, dir, nt, sus) hit(false, dir) end

function onTweenCompleted(tag)
	if string.sub(tag, 1, 11) == 'fnmmFlashT' then removeLuaSprite('fnmmFlash' .. string.sub(tag, 12), true) end
end
