package com.portyou.studio.convert

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import kotlin.math.ceil
import kotlin.math.max
import kotlin.math.min
import kotlin.math.roundToInt

/** Line-by-line port of tools/fnmm_to_psych.py (the verified reference implementation). */
class FunkyMakerConverter(private val ctx: Context) {
    private val dirs = listOf("idle", "singLEFT", "singDOWN", "singUP", "singRIGHT", "miss", "special")
    private val xmlp = listOf("idle_", "left_", "down_", "up_", "right_", "miss_", "special_")
    private val baseFps = 10.0
    private val catalog = setOf("ScreenFlash", "CameraShake", "CameraSet", "BarIconChange", "ObjectSpriteSet", "ObjectChartChange",
        "ObjectAnimationSet", "ObjectVisibilitySet", "ObjectOpacitySet", "PlayerHealth", "RunActionPack", "GUI",
        "ObjectBlendColor", "CameraZoom", "ObjectPositionSet")

    private fun slug(s: String): String {
        val r = s.lowercase().replace(Regex("[^a-z0-9_-]+"), "-").trim('-')
        return if (r.count { it.isLetterOrDigit() } >= 2) r else "fnmm-mod"
    }
    private fun lua(s: String) = "'" + s.replace("\\", "\\\\").replace("'", "\\'") + "'"
    private fun num(d: Double) = if (d == Math.floor(d) && Math.abs(d) < 1e12) d.toLong().toString() else d.toString()
    private fun rd(f: File) = JSONObject(f.readText())
    private fun save(b: Bitmap, f: File) { f.parentFile?.mkdirs(); f.outputStream().use { b.compress(Bitmap.CompressFormat.PNG, 100, it) } }

    private class Strip(val a: JSONObject, val img: Bitmap)

    fun convert(root: File, outRoot: File, originalName: String, report: MutableList<String>): String {
        val data = rd(File(root, "data.json")); val scene = rd(File(root, "scene.json")); val eventsFile = File(root, "events.json"); val events = if (eventsFile.isFile) rd(eventsFile) else JSONObject()
        val name = slug(originalName.substringBeforeLast('.'))
        val song = name
        val out = File(outRoot, name).also { it.mkdirs() }
        fun P(vararg p: String) = File(out, p.joinToString("/"))
        val bpm = data.optDouble("bpm", 120.0)
        val beatMs = 60000.0 / bpm; val secMs = beatMs * 4

        // ---------- chart ----------
        class N(val ms: Double, val d: Int, val len: Double, val type: String)
        val notes = ArrayList<N>(); var last = 0.0
        val sls = data.getJSONArray("strumLines")
        // psych_v1 = ABSOLUTE lanes: 0-3 player, 4-7 opponent. strumLine 0 = player, 1 = opponent, 2+ = girlfriend ('GF Sing' on the opponent side).
        for (sl in 0 until sls.length()) {
            val lanes = sls.getJSONArray(sl)
            for (lane in 0 until min(4, lanes.length())) {
                val lst = lanes.getJSONArray(lane)
                for (i in 0 until lst.length()) {
                    val n = lst.getJSONObject(i)
                    val ms = n.getDouble("start") * 1000.0
                    var ln = n.optDouble("duration", 0.0) * 1000.0
                    if (ln < beatMs / 8) ln = 0.0
                    notes.add(N(ms, lane + (if (sl == 0) 0 else 4), ln, if (sl >= 2) "GF Sing" else "")); last = max(last, ms + ln)
                }
            }
        }
        val nsec = (last / secMs).toInt() + 2
        val secs = Array(nsec) { JSONObject().put("sectionNotes", JSONArray()).put("sectionBeats", 4).put("mustHitSection", true)
            .put("gfSection", false).put("bpm", bpm).put("changeBPM", false) }
        for (n in notes.sortedWith(compareBy({ it.ms }, { it.d }))) secs[(n.ms / secMs).toInt()].getJSONArray("sectionNotes").put(JSONArray().put(n.ms).put(n.d).put(n.len).put(n.type))
        val objs = scene.getJSONArray("objects")
        // FNMM v4 stores position/scale/scrollFactor inside transform[0].
        // Older exports put those values directly on each scene object; accept both.
        fun transformOf(o: JSONObject): JSONObject = o.optJSONObject("transform") ?: o.optJSONArray("transform")?.optJSONObject(0) ?: JSONObject()
        fun positionOf(o: JSONObject): JSONObject = transformOf(o).optJSONObject("position") ?: o.optJSONObject("position") ?: o
        fun scaleOf(o: JSONObject): JSONObject = transformOf(o).optJSONObject("scale") ?: o.optJSONObject("scale") ?: JSONObject()
        fun scrollOf(o: JSONObject): JSONObject = transformOf(o).optJSONObject("scrollFactor") ?: o.optJSONObject("scrollFactor") ?: JSONObject()
        fun px(o: JSONObject) = positionOf(o).optDouble("x", o.optDouble("x", 0.0))
        fun py(o: JSONObject) = positionOf(o).optDouble("y", o.optDouble("y", 0.0))
        fun sx(o: JSONObject) = scaleOf(o).optDouble("x", o.optDouble("scale", 1.0))
        fun sy(o: JSONObject) = scaleOf(o).optDouble("y", sx(o))
        fun scrollX(o: JSONObject) = scrollOf(o).optDouble("x", 1.0)
        fun scrollY(o: JSONObject) = scrollOf(o).optDouble("y", 1.0)
        val charObj = HashMap<Int, Int>()
        for (i in 0 until objs.length()) { val sl = objs.getJSONObject(i).optDouble("strumLine", -1.0).toInt(); if ((sl == 0 || sl == 1) && sl !in charObj) charObj[sl] = i }
        P("data", song, "$song.json").also { it.parentFile?.mkdirs() }.writeText(JSONObject()
            .put("song", song).put("notes", JSONArray(secs.toList())).put("bpm", bpm).put("needsVoices", false).put("speed", 2.5).put("offset", 0)
            .put("player1", "fnmm-player").put("player2", if (1 in charObj) "fnmm-enemy" else "bf").put("gfVersion", "gf").put("stage", name).put("events", JSONArray())
            .put("format", "psych_v1").put("arrowSkin", "").put("splashSkin", "noteSplashes/noteSplashes").toString(1))

        // ---------- sprites ----------
        val spr = HashMap<String, JSONObject>()
        File(root, "sprites").listFiles()?.filter { File(it, "sprite.json").isFile }?.forEach { spr[it.name] = rd(File(it, "sprite.json")) }
        fun strips(sn: String, limit: Int = Int.MAX_VALUE): List<Strip> {
            val d = spr[sn]!!.getJSONArray("data")
            return (0 until min(d.length(), limit)).map { index ->
                val imageFile = File(root, "sprites/$sn/$index.png")
                val image = BitmapFactory.decodeFile(imageFile.path)
                    ?: throw UnsupportedModException("FNMM sprite image is missing or unreadable: ${imageFile.relativeTo(root).path}")
                Strip(d.getJSONObject(index), image)
            }
        }
        fun numOf(a: JSONObject) = max(1, a.get("num").toString().toDouble().toInt())
        fun frames(s: Strip): List<Bitmap> {
            val n = numOf(s.a); val fw = s.img.width / n
            if (fw <= 0) throw UnsupportedModException("Invalid FNMM animation strip width")
            return (0 until n).map { Bitmap.createBitmap(s.img, it * fw, 0, fw, s.img.height) }
        }
        fun fps(a: JSONObject) = if (a.optBoolean("spd_fps")) a.getDouble("spd") else a.getDouble("spd") * baseFps

        class CharInfo(val cw: Int, val ch: Int, val scale: Double, val o: JSONObject)
        val chars = HashMap<String, CharInfo>()
        for ((sl, key) in listOf(0 to "fnmm-player", 1 to "fnmm-enemy")) {
            val oi = charObj[sl] ?: continue
            val o = objs.getJSONObject(oi); val sn = o.getString("spr"); val sc = sx(o)
            val st = strips(sn); val fr = st.map { frames(it) }
            val pres = st.indices.map { if (it < xmlp.size) xmlp[it] else "extra${it}_" }
            val cw = fr.maxOf { l -> l.maxOf { it.width } }; val chh = fr.maxOf { l -> l.maxOf { it.height } }
            val groups = fr.mapIndexed { index, list -> Atlas.Group(pres[index], list) }
            val pages = try {
                Atlas.packSparrowMulti(groups, P("images", "characters", "$key.png"), P("images", "characters", "$key.xml"))
            } finally {
                fr.flatten().forEach { if (!it.isRecycled) it.recycle() }
                st.forEach { if (!it.img.isRecycled) it.img.recycle() }
            }
            val anims = JSONArray()
            for ((i, s) in st.withIndex()) {
                val an = if (i < dirs.size) dirs[i] else "extra$i"
                fun anim(nm: String) = JSONObject().put("loop", an == "idle" && s.a.optBoolean("loop", true)).put("offsets", JSONArray().put(0).put(0))
                    .put("anim", nm).put("fps", fps(s.a).roundToInt()).put("name", pres[i]).put("indices", JSONArray())
                anims.put(anim(an))
                if (an == "miss") for (d in listOf("LEFT", "DOWN", "UP", "RIGHT")) anims.put(anim("sing${d}miss"))
            }
            chars[key] = CharInfo(cw, chh, sc, o)
            P("characters", "$key.json").also { it.parentFile?.mkdirs() }.writeText(JSONObject().put("animations", anims).put("vocals_file", "")
                .put("no_antialiasing", false).put("image", pages.joinToString(",")).put("position", JSONArray().put(0).put(0)).put("healthicon", key)
                .put("flip_x", sl == 0).put("healthbar_colors", if (sl == 0) JSONArray("[252,252,4]") else JSONArray("[252,4,108]"))
                .put("camera_position", JSONArray().put(0).put(0)).put("sing_duration", 4).put("scale", sc).put("_editor_isPlayer", sl == 0).toString(1))
        }
        // icons: every type-3 sprite -> icon-fnmm-<name>.png (two frames side by side)
        val icons = scene.optJSONArray("icons") ?: JSONArray()
        for ((sn, sj) in spr) {
            if (sj.getDouble("type").toInt() != 3) continue
            val fr = strips(sn, 2).map { it.img }.toMutableList(); if (fr.isEmpty()) continue
            while (fr.size < 2) fr.add(fr[0])
            val w = fr.maxOf { it.width }; val h = fr.maxOf { it.height }
            val sh = Bitmap.createBitmap(w * 2, h, Bitmap.Config.ARGB_8888); val cv = Canvas(sh)
            fr.forEachIndexed { j, f -> cv.drawBitmap(f, (j * w).toFloat(), 0f, null) }
            try {
                save(sh, P("images", "icons", "icon-fnmm-$sn.png"))
                for (i in 0 until min(2, icons.length())) if (icons.getString(i) == sn) save(sh, P("images", "icons", "icon-${if (i == 0) "fnmm-player" else "fnmm-enemy"}.png"))
            } finally {
                sh.recycle()
                fr.distinct().forEach { if (!it.isRecycled) it.recycle() }
            }
        }
        // world objects + sprite registry (types 0 and 2 are plain strips)
        val saved = HashSet<String>()
        fun animLua(sn: String): String {
            val source = strips(sn)
            return try {
                source.withIndex().joinToString(", ") { (k, s) ->
                    val n = numOf(s.a)
                    val fw = s.img.width / n; val fh = s.img.height
                    if (saved.add("$sn$k")) save(s.img, P("images", name, "${sn}_$k.png"))
                    "{img=${lua("$name/${sn}_$k")}, fw=$fw, fh=$fh, frames=$n, fps=${num(fps(s.a))}, loop=${s.a.optBoolean("loop", true)}}"
                }
            } finally { source.forEach { if (!it.img.isRecycled) it.img.recycle() } }
        }
        val objLua = ArrayList<String>()
        for (i in 0 until objs.length()) {
            val o = objs.getJSONObject(i); val sn = o.getString("spr")
            if (i in charObj.values || sn !in spr) continue
            val color = o.optJSONObject("color") ?: JSONObject()
            val colorHex = "%02X%02X%02X".format(color.optInt("r", 255).coerceIn(0, 255), color.optInt("g", 255).coerceIn(0, 255), color.optInt("b", 255).coerceIn(0, 255))
            objLua.add("\t{idx=$i, spr=${lua(sn)}, cx=${num(px(o))}, cy=${num(py(o))}, scale=${num(sx(o))}, scaleY=${num(sy(o))}, " +
                "scrollX=${num(scrollX(o))}, scrollY=${num(scrollY(o))}, alpha=${num(o.optDouble("opacity", o.optDouble("alpha", 1.0)))}, angle=${num(o.optDouble("angle", 0.0))}, color=${lua(colorHex)}, " +
                "visible=${o.optBoolean("visible", true)}, fixed=${o.optBoolean("fixed", false)}, anims={${animLua(sn)}}},")
        }
        val sprLua = spr.filter { it.value.getDouble("type").toInt() in listOf(0, 2) }.map { "\t[${lua(it.key)}] = {${animLua(it.key)}}," }

        // ---------- stage ----------
        val cams = scene.optJSONArray("cameras") ?: JSONArray("[{\"x\":1080,\"y\":960,\"scale\":1}]")
        val cam = cams.getJSONObject(0)
        fun tl(sl: Int): JSONArray { val c = chars[if (sl == 0) "fnmm-player" else "fnmm-enemy"] ?: return JSONArray().put(0).put(0)
            return JSONArray().put(px(c.o) - c.cw * c.scale / 2).put(py(c.o) - c.ch * c.scale / 2) }
        P("stages", "$name.json").also { it.parentFile?.mkdirs() }.writeText(JSONObject().put("directory", "").put("defaultZoom", cam.optDouble("scale", 1.0) * 0.7)
            .put("isPixelStage", false).put("boyfriend", tl(0)).put("girlfriend", JSONArray("[400,130]")).put("opponent", tl(1)).put("hide_girlfriend", true)
            .put("camera_boyfriend", JSONArray("[0,0]")).put("camera_opponent", JSONArray("[0,0]")).put("camera_girlfriend", JSONArray("[0,0]")).put("camera_speed", 100).toString(1))

        // ---------- events (every FNMM action -> [Type, "k=v;k=v", ""]) ----------
        val packs = events.optJSONArray("action_packs") ?: JSONArray(); val unknown = sortedSetOf<String>()
        fun flat(p: JSONObject, pre: String = ""): List<String> = p.keys().asSequence().flatMap { k ->
            val v = p.get(k)
            if (v is JSONObject) flat(v, "$pre$k.").asSequence() else sequenceOf("$pre$k=" + (if (v is Double && v == Math.floor(v)) v.toLong().toString()
                else if (v is Boolean) (if (v) "1" else "0") else v.toString()).replace(";", ","))
        }.toList()
        fun expand(actions: JSONArray, depth: Int, outl: MutableList<JSONArray>) {
            for (i in 0 until actions.length()) {
                val a = actions.getJSONObject(i); val t = a.getString("type"); val p = a.optJSONObject("props") ?: JSONObject()
                if (t == "RunActionPack") { val pi = p.optDouble("actionPack", 0.0).toInt(); if (depth < 8 && pi in 0 until packs.length()) expand(packs.getJSONObject(pi).getJSONArray("actions"), depth + 1, outl); continue }
                if (t !in catalog) unknown.add(t)
                outl.add(JSONArray().put(t).put(flat(p).joinToString(";")).put(""))
            }
        }
        val evl = ArrayList<Pair<Double, List<JSONArray>>>(); val used = sortedSetOf<String>()
        val evs = events.optJSONArray("events") ?: JSONArray()
        for (i in 0 until evs.length()) {
            val ev = evs.getJSONObject(i); val row = ArrayList<JSONArray>(); expand(ev.optJSONArray("actions") ?: JSONArray(), 0, row)
            if (row.isNotEmpty()) { evl.add(ev.getDouble("time") * 1000.0 to row); row.forEach { used.add(it.getString(0)) } }
        }
        evl.sortBy { it.first }
        val evJson = JSONArray(); for ((t, r) in evl) evJson.put(JSONArray().put(t).put(JSONArray(r)))
        // events live INSIDE the chart (a chart without an "events" key = Null Object Reference in PlayState.generateSong)
        val chartFile = P("data", song, "$song.json")
        chartFile.writeText(JSONObject(chartFile.readText()).put("events", evJson).toString(1))
        for (t in used) P("custom_events", "$t.txt").also { it.parentFile?.mkdirs() }.writeText("FNMM $t (executed by scripts/fnmm_runtime.lua)")
        if (unknown.isNotEmpty()) report.add("Unknown FNMM actions kept as events (manual work needed): " + unknown.joinToString())

        // ---------- runtime ----------
        val camsLua = (0 until cams.length()).joinToString(", ") { val c = cams.getJSONObject(it); "{${num(px(c))}, ${num(py(c))}, ${num(c.optDouble("scale", 1.0))}}" }
        val rt = ctx.assets.open("converter/fnmm_runtime.lua").bufferedReader().readText()
            .replace("--[[CAMS]]", camsLua).replace("--[[OBJS]]", objLua.joinToString("\n")).replace("--[[SPRS]]", sprLua.joinToString("\n"))
            .replace("--[[CHAROBJ]]", "local CHAR_OBJ = {[0]=${charObj[0] ?: -1}, [1]=${charObj[1] ?: -1}}")
        P("scripts", "fnmm_runtime.lua").also { it.parentFile?.mkdirs() }.writeText(rt)

        // ---------- week / pack / audio ----------
        P("weeks", "$name.json").also { it.parentFile?.mkdirs() }.writeText(JSONObject().put("songs", JSONArray().put(JSONArray().put(song).put(if (1 in charObj) "fnmm-enemy" else "bf").put(JSONArray("[252,4,108]"))))
            .put("weekCharacters", JSONArray("[\"\",\"bf\",\"gf\"]")).put("weekBackground", "").put("weekBefore", "tutorial").put("storyName", name).put("weekName", name)
            .put("startUnlocked", true).put("hideStoryMode", true).put("hideFreeplay", false).put("difficulties", "Normal").toString(1))
        Credits.write(ctx, out, name, intArrayOf(252, 4, 108))
        root.walkTopDown().filter { it.isFile && it.extension.lowercase() in listOf("ogg", "mp3", "wav") }.forEach {
            val rel = it.relativeTo(root).path
            val dst = P("songs", song, if (rel.startsWith("music")) "Inst.ogg" else it.name).also { f -> f.parentFile?.mkdirs() }
            it.copyTo(dst, overwrite = true)
        }
        return name
    }
}
