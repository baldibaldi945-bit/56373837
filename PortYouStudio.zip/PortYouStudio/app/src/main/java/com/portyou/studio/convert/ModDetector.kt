package com.portyou.studio.convert

import java.io.File

enum class ModType { FUNKY_MAKER, VSLICE, UNKNOWN }

// Case-insensitive, content-first detection. FNMM is a ZIP container, not merely a filename suffix.
object ModDetector {
    fun detect(dir: File): Pair<ModType, File> {
        val roots = sequenceOf(dir) + dir.walkTopDown().filter { it.isDirectory }.take(12000)
        for (root in roots) {
            val names = root.list()?.map { it.lowercase() }?.toSet() ?: emptySet()
            if ("data.json" in names && "scene.json" in names && "sprites" in names && File(root, "sprites").isDirectory) {
                return ModType.FUNKY_MAKER to root
            }
            if ("_polymod_meta.json" in names || ("data" in names && File(root, "data/songs").isDirectory &&
                    File(root, "shared").isDirectory)) return ModType.VSLICE to root
        }
        // Some V-Slice archives omit Polymod metadata. Locate the nearest folder containing chart/metadata files.
        val candidates = dir.walkTopDown().take(20000).filter { it.isFile }.toList()
        val chart = candidates.firstOrNull { it.name.endsWith("-chart.json", ignoreCase = true) || it.name.endsWith("-metadata.json", ignoreCase = true) }
        if (chart != null) {
            var root = chart.parentFile ?: dir
            while (root.parentFile != null && root.parentFile != dir && root.parentFile!!.name != "data") root = root.parentFile!!
            return ModType.VSLICE to (root.parentFile?.parentFile ?: dir)
        }
        return ModType.UNKNOWN to dir
    }
}
