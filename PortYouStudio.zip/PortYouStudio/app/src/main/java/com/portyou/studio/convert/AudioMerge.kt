package com.portyou.studio.convert

import com.arthenica.ffmpegkit.FFmpegKit
import com.arthenica.ffmpegkit.ReturnCode
import java.io.File

/**
 * Merges several vocal tracks into one OGG (Psych 1.0 loads only Voices-Player.ogg / Voices-Opponent.ogg).
 * Uses the audio-only FFmpegKit build (libvorbis + amix), the same filter the Python tool used:
 *   ffmpeg -i a.ogg -i b.ogg -filter_complex "[0:a][1:a]amix=inputs=2:normalize=0" -c:a libvorbis out.ogg
 * If the native library is missing or ffmpeg fails, the first track is copied and false is returned (the caller reports it).
 */
object AudioMerge {
    fun merge(inputs: List<File>, out: File): Boolean {
        out.parentFile?.mkdirs()
        if (inputs.isEmpty()) return false
        if (inputs.size == 1) { inputs[0].copyTo(out, overwrite = true); return true }
        return try {
            val args = ArrayList<String>()
            args += listOf("-y", "-loglevel", "error")
            for (f in inputs) { args += "-i"; args += f.absolutePath }
            args += "-filter_complex"
            args += inputs.indices.joinToString("") { "[$it:a]" } + "amix=inputs=${inputs.size}:normalize=0"
            args += listOf("-c:a", "libvorbis", "-q:a", "4", out.absolutePath)
            val session = FFmpegKit.executeWithArguments(args.toTypedArray())
            if (ReturnCode.isSuccess(session.returnCode) && out.isFile && out.length() > 0) true
            else { out.delete(); inputs[0].copyTo(out, overwrite = true); false }
        } catch (t: Throwable) {        // UnsatisfiedLinkError / NoClassDefFoundError on unsupported CPUs
            out.delete(); inputs[0].copyTo(out, overwrite = true); false
        }
    }
}
