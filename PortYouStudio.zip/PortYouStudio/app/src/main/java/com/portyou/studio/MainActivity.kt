package com.portyou.studio

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.View
import android.view.ViewGroup
import android.widget.FrameLayout
import android.widget.Toast
import android.widget.VideoView
import androidx.documentfile.provider.DocumentFile
import com.portyou.studio.convert.*
import java.io.File
import kotlin.concurrent.thread

class MainActivity : Activity(), StudioView.Host {
    private lateinit var prefs: Prefs
    private lateinit var sound: Sound
    private lateinit var view: StudioView
    private lateinit var root: FrameLayout
    private var pickKind = 0
    private var resultDir: File? = null
    private var resultName = ""
    @Volatile private var working = false

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        prefs = Prefs(this); sound = Sound(this, prefs); view = StudioView(this, prefs, sound, this)
        root = FrameLayout(this); root.addView(view, ViewGroup.LayoutParams(-1, -1)); setContentView(root)
        playIntro()
    }

    /** The intro video sits above everything but never blocks touches (the app is usable while it plays). */
    private fun playIntro() {
        val f = File(cacheDir, "intro.mp4")
        if (!f.exists()) assets.open("ui/intro.mp4").use { i -> f.outputStream().use { i.copyTo(it) } }
        val v = VideoView(this).apply { isClickable = false; isFocusable = false; setZOrderOnTop(true) }
        root.addView(v, FrameLayout.LayoutParams(-1, -1))
        v.setOnCompletionListener { root.removeView(v) }
        v.setOnErrorListener { _, _, _ -> root.removeView(v); true }
        v.setVideoPath(f.path); v.start()
    }

    override fun onStart() { super.onStart(); sound.startMusic() }
    override fun onStop() { super.onStop(); sound.pauseMusic() }
    override fun onDestroy() { super.onDestroy(); sound.release() }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (view.screen == StudioView.Screen.SETTINGS) view.leaveSettings() else super.onBackPressed()
    }

    override fun openUrl(url: String) { try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url))) } catch (_: Exception) {} }

    // ---------------- picking ----------------
    override fun pickMod(kind: Int) {
        pickKind = kind
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE); type = "*/*"
            putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false)   // exactly one mod
            putExtra(Intent.EXTRA_TITLE, Strings.pickTitle[prefs.lang])
        }
        startActivityForResult(i, REQ_PICK)
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        when (req) {
            REQ_PICK -> {
                val uri = data?.data
                if (res != RESULT_OK || uri == null) { view.showMain(); return }
                startConversion(uri)
            }
            REQ_TREE -> {
                val uri = data?.data
                if (res == RESULT_OK && uri != null) {
                    contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION)
                    prefs.saveTree = uri.toString(); saveResult()
                }
            }
        }
    }

    // ---------------- conversion (runs while the loading screen is shown) ----------------
    private fun startConversion(uri: Uri) {
        if (working) return
        var fname = "mod"; var size = -1L
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                c.getColumnIndex(OpenableColumns.DISPLAY_NAME).takeIf { it >= 0 }?.let { fname = c.getString(it) }
                c.getColumnIndex(OpenableColumns.SIZE).takeIf { it >= 0 }?.let { size = c.getLong(it) }
            }
        }
        // The file picker may return a MIME-based name with no reliable extension.
        // Validate the actual archive header and detect the mod's contents instead.
        if (size > MAX_BYTES) { view.showFail(); Toast.makeText(this, "حجم الملف أكبر من الحد المسموح", Toast.LENGTH_LONG).show(); return }
        view.showLoading(); working = true
        thread(name = "convert") {
            val work = File(cacheDir, "work"); work.deleteRecursively(); work.mkdirs()
            var ok = false
            var failure = "تعذّر تحويل الملف"
            try {
                val src = File(work, "in.bin")
                val input = contentResolver.openInputStream(uri) ?: throw UnsupportedModException("لا يمكن قراءة الملف المحدد")
                input.use { i -> src.outputStream().use { o ->
                    val buffer = ByteArray(64 * 1024); var total = 0L
                    while (true) {
                        val n = i.read(buffer); if (n < 0) break
                        total += n
                        if (total > MAX_BYTES) throw UnsupportedModException("حجم الملف أكبر من الحد المسموح")
                        o.write(buffer, 0, n)
                    }
                } }
                val ex = File(work, "x"); Archive.extract(src, ex); src.delete()
                val report = ArrayList<String>()
                Astc.convertTree(ex, report)   // ASTC / KTX textures -> PNG before anything reads them
                val (type, mroot) = ModDetector.detect(ex)
                val out = File(work, "out")
                // Select the converter from the archive contents; FNMM works even when chosen via the other button.
                resultName = when (type) {
                    ModType.FUNKY_MAKER -> FunkyMakerConverter(this).convert(mroot, out, fname, report)
                    ModType.VSLICE -> VSliceConverter(this).convert(mroot, out, fname, report)
                    ModType.UNKNOWN -> throw UnsupportedModException("لم أتعرف على نوع المود. تأكد أنه V-Slice أو FNMM كامل.")
                }
                if (report.isNotEmpty()) File(out, "$resultName/PORTYOU_REPORT.txt").writeText(report.joinToString("\n"))
                resultDir = File(out, resultName); ok = true
            } catch (t: Throwable) {
                failure = (t.message ?: t.javaClass.simpleName).take(450)
                ok = false
            } finally { working = false }
            runOnUiThread {
                if (ok) view.showSuccess() else {
                    view.showFail()
                    Toast.makeText(this, "فشل التحويل: $failure", Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    // ---------------- saving ----------------
    override fun onSuccessOk() {
        if (prefs.saveTree == null) {
            startActivityForResult(Intent(Intent.ACTION_OPEN_DOCUMENT_TREE).addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION or
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION), REQ_TREE)
        } else saveResult()
    }

    private fun saveResult() {
        val src = resultDir; val treeStr = prefs.saveTree
        if (src == null || treeStr == null) { view.showMain(); return }
        val tree = DocumentFile.fromTreeUri(this, Uri.parse(treeStr))
        if (tree == null || !tree.exists() || !tree.canWrite()) {      // folder was deleted: ask again
            prefs.saveTree = null; onSuccessOk(); return
        }
        thread {
            val label = try {
                copyTree(src, tree, resultName)
                File(src.parentFile, resultName + "_unconverted").takeIf { it.isDirectory }?.let { copyTree(it, tree, resultName + "_unconverted") }
                tree.name ?: ""
            } catch (t: Throwable) { null }
            runOnUiThread {
                view.showMain()
                Toast.makeText(this, if (label != null) Strings.savedIn[prefs.lang] + label + "/" + resultName else "Save failed", Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun copyTree(src: File, parent: DocumentFile, name: String) {
        var n = name; var k = 1
        while (parent.findFile(n) != null) n = "$name-${k++}"
        val dir = parent.createDirectory(n) ?: throw java.io.IOException("mkdir")
        fun rec(f: File, d: DocumentFile) {
            f.listFiles()?.forEach { c ->
                if (c.isDirectory) rec(c, d.createDirectory(c.name)!!)
                else {
                    val mime = when (c.extension.lowercase()) { "png" -> "image/png"; "ogg" -> "audio/ogg"; else -> "application/octet-stream" }
                    val df = d.createFile(mime, c.name)!!
                    contentResolver.openOutputStream(df.uri)!!.use { o -> c.inputStream().use { it.copyTo(o) } }
                }
            }
        }
        rec(src, dir)
    }

    companion object { const val REQ_PICK = 1; const val REQ_TREE = 2; const val MAX_BYTES = 2L * 1024 * 1024 * 1024 }
}
