package com.portyou.studio.convert

import org.json.JSONObject
import java.io.File

/**
 * Kotlin port of tools/portyou/hx2lua.py: Haxe (.hx/.hxc, V-Slice + HScript style) -> Psych Engine Lua, PER FUNCTION.
 * A function that cannot be translated with certainty is not guessed: it is reported and left out.
 * Rules come from assets/converter/methods.json ("haxe"), the same file the Python tool uses.
 */
class Hx2Lua(methodsJson: String, learnedKnowledgeJson: String = "{}") {
    class Unconvertible(msg: String) : Exception(msg)
    class Failure(val file: String, val fn: String, val why: String, val code: String)
    class Result { val failed = ArrayList<Failure>(); var ok = 0 }
    class HxFile(val path: File, val kind: String, val event: String?)

    private val kb = JSONObject(methodsJson).optJSONObject("haxe") ?: JSONObject()
    private val learned = runCatching { JSONObject(learnedKnowledgeJson) }.getOrDefault(JSONObject())
    private val callbacks = HashMap<String, String>().also { m ->
        kb.optJSONObject("callbacks")?.let { o -> o.keys().forEach { k -> m[k.trim()] = o.getString(k) } }
        learned.optJSONObject("callbacks")?.let { o -> o.keys().forEach { k -> m.putIfAbsent(k.trim(), o.getString(k)) } }
    }
    private val apiRules = ArrayList<Pair<Regex, String>>()
    private val unsupported = ArrayList<Pair<Regex, String>>()
    private var switchCounter = 0
    private val moduleInitializers = ArrayList<String>()

    init {
        kb.optJSONArray("api_rules")?.let { for (i in 0 until it.length()) { val r = it.getJSONArray(i); apiRules.add(Regex(r.getString(0)) to r.getString(1)) } }
        kb.optJSONArray("unsupported")?.let { for (i in 0 until it.length()) { val r = it.getJSONArray(i); unsupported.add(Regex(r.getString(0)) to r.getString(1)) } }
        learned.optJSONArray("api_rules")?.let { for (i in 0 until it.length()) { val r = it.getJSONArray(i); apiRules.add(Regex(r.getString(0)) to r.getString(1)) } }
        learned.optJSONArray("unsupported")?.let { for (i in 0 until it.length()) { val r = it.getJSONArray(i); unsupported.add(Regex(r.getString(0)) to r.getString(1)) } }
    }

    // ------------------------------------------------------------------ lexical helpers
    private fun stripComments(src: String): String {
        val out = StringBuilder(); var i = 0; val n = src.length; var q: Char? = null
        while (i < n) {
            val c = src[i]
            if (q != null) {
                out.append(c)
                if (c == '\\' && i + 1 < n) { out.append(src[i + 1]); i += 2; continue }
                if (c == q) q = null
                i++; continue
            }
            if (c == '"' || c == '\'') { q = c; out.append(c); i++; continue }
            if (src.startsWith("//", i)) { while (i < n && src[i] != '\n') i++; continue }
            if (src.startsWith("/*", i)) { val j = src.indexOf("*/", i + 2); i = if (j < 0) n else j + 2; continue }
            out.append(c); i++
        }
        return out.toString()
    }

    private fun matchBrace(src: String, start: Int): Int {
        var i = start; var d = 0; var q: Char? = null; val n = src.length
        while (i < n) {
            val c = src[i]
            if (q != null) {
                if (c == '\\') { i += 2; continue }
                if (c == q) q = null
            } else if (c == '"' || c == '\'') q = c
            else if (c == '{') d++
            else if (c == '}') { d--; if (d == 0) return i }
            i++
        }
        throw Unconvertible("unbalanced braces")
    }

    private sealed class Member {
        class Fn(val name: String, val args: String, val body: String) : Member()
        class Var(val text: String) : Member()
    }

    private val fre = Regex("(?:(?:override|public|private|static|inline)\\s+)*function\\s+(\\w+)\\s*\\(([^)]*)\\)\\s*(?::\\s*[\\w.<>]+)?\\s*\\{")
    private val vre = Regex("(?:(?:public|private|static|inline)\\s+)*(?:var|final)\\s+[^;{]*;")

    private fun splitMembers(source: String): List<Member> {
        val src = stripComments(source)
        var body = src
        val classHeads = Regex("\\bclass\\s+\\w+[^\\{]*\\{").findAll(src).toList()
        if (classHeads.isNotEmpty()) {
            body = classHeads.joinToString("\n") { m ->
                val end = matchBrace(src, m.range.last)
                src.substring(m.range.last + 1, end)
            }
        }
        val members = ArrayList<Member>(); var i = 0
        while (i < body.length) {
            val f = fre.find(body, i); val v = vre.find(body, i)
            if (f != null && (v == null || f.range.first < v.range.first)) {
                val end = matchBrace(body, f.range.last)
                members.add(Member.Fn(f.groupValues[1], f.groupValues[2], body.substring(f.range.last + 1, end)))
                i = end + 1
            } else if (v != null) { members.add(Member.Var(v.value)); i = v.range.last + 1 } else break
        }
        return members
    }

    // ------------------------------------------------------------------ module compatibility
    /**
     * V-Slice often keeps a ScriptedModule class beside its SongEvent in one .hxc file.
     * Lua has no Haxe class loader, so keep module state in a private table and expose
     * module callbacks as ordinary Psych callbacks. This covers simple stateful modules;
     * complex engine modules still go to the unconverted report.
     */
    private fun prepareModuleClasses(source: String): Pair<String, Boolean> {
        var src = source
        val heads = Regex("\\bclass\\s+(\\w+)\\s+extends\\s+(?:Scripted)?Module\\s*\\{").findAll(src).toList()
        if (heads.isEmpty()) return src to false
        for (head in heads.asReversed()) {
            val className = head.groupValues[1]
            val end = matchBrace(src, head.range.last)
            val access = "__portyou_modules.$className"
            var body = src.substring(head.range.last + 1, end)
            // Psych's onUpdate receives elapsed as a number, while V-Slice Module receives
            // UpdateScriptEvent.elapsed. Keep the value but remove the event-object dereference.
            body = Regex("\\be\\.elapsed\\b").replace(body, "e")
            val fields = LinkedHashSet<String>()
            val arrayFields = LinkedHashSet<String>()
            val functionRanges = Regex("\\bfunction\\s+\\w+\\s*\\([^)]*\\)[^{]*\\{").findAll(body).map { f ->
                (f.range.last + 1) to matchBrace(body, f.range.last)
            }.toList()
            val fieldRx = Regex("(?m)(?:(?:public|private|static|final)\\s+)*var\\s+(\\w+)\\s*(?::\\s*([\\w.<>]+))?\\s*(?:=\\s*([^;]+))?;")
            body = fieldRx.replace(body) { m ->
                val field = m.groupValues[1]; fields.add(field)
                if (m.groupValues[2].startsWith("Array<")) arrayFields.add(field)
                val value = m.groupValues.getOrNull(3)?.trim().orEmpty().ifEmpty { "nil" }
                val local = functionRanges.any { m.range.first >= it.first && m.range.first < it.second }
                if (!local) { moduleInitializers.add("$access.$field = $value"); "" }
                else "$access.$field = $value;"
            }
            // Avoid rewriting identifiers inside quoted strings and already-qualified fields.
            val strings = ArrayList<String>()
            var protected = strRx.replace(body) { m -> strings.add(m.value); "\\u0000M${strings.size - 1}\\u0000" }
            for (field in fields) {
                protected = Regex("\\bthis\\.${Regex.escape(field)}\\b").replace(protected) { "$access.$field" }
                protected = Regex("(?<![.\\w])${Regex.escape(field)}\\b").replace(protected) { "$access.$field" }
            }
            protected = shiftArrayIndexes(protected, access, arrayFields)
            for ((i, literal) in strings.withIndex()) protected = protected.replace("\\u0000M$i\\u0000", literal)
            body = protected
            src = src.replaceRange(head.range.last + 1, end, body)
        }
        src = Regex("ModuleHandler\\.getModule\\(\\s*(['\"])([A-Za-z_][A-Za-z0-9_]*)\\1\\s*\\)").replace(src) { "__portyou_modules.${it.groupValues[2]}" }
        return src to true
    }

    /** Haxe arrays are zero-based; Psych Lua tables are one-based. Handles nested brackets safely. */
    private fun shiftArrayIndexes(source: String, moduleAccess: String, arrayFields: Set<String>): String {
        var result = source
        for (field in arrayFields) {
            val token = "$moduleAccess.$field"
            val out = StringBuilder(); var cursor = 0
            while (cursor < result.length) {
                val at = result.indexOf(token, cursor)
                if (at < 0) { out.append(result.substring(cursor)); break }
                val afterToken = at + token.length
                var open = afterToken
                while (open < result.length && result[open].isWhitespace()) open++
                if (open >= result.length || result[open] != '[') {
                    out.append(result, cursor, afterToken); cursor = afterToken; continue
                }
                var depth = 1; var j = open + 1; var quote: Char? = null
                while (j < result.length && depth > 0) {
                    val c = result[j]
                    if (quote != null) {
                        if (c == '\\') j++ else if (c == quote) quote = null
                    } else when (c) {
                        '\'' , '\"' -> quote = c
                        '[' -> depth++
                        ']' -> depth--
                    }
                    j++
                }
                if (depth != 0) { out.append(result, cursor, afterToken); cursor = afterToken; continue }
                val indexExpr = result.substring(open + 1, j - 1)
                out.append(result, cursor, at).append(token).append("[(").append(indexExpr).append(") + 1]")
                cursor = j
            }
            result = out.toString()
        }
        return result
    }

    // ------------------------------------------------------------------ expressions
    private val strRx = Regex("\"(?:\\\\.|[^\"\\\\])*\"|'(?:\\\\.|[^'\\\\])*'")
    private val leftRx = Regex("\\b(?:game|FlxG|Flx[A-Z]\\w*|Paths|ClientPrefs|PlayState|Conductor)\\.\\w+")

    private fun expand(rep: String, m: MatchResult): String =
        Regex("\\\\(\\d)").replace(rep) { g -> m.groupValues.getOrElse(g.groupValues[1].toInt()) { "" } }

    private fun convExpr(src: String): String {
        var e = src.trim()
        for ((rx, why) in unsupported) if (rx.containsMatchIn(e)) throw Unconvertible(why)
        val strs = ArrayList<String>()
        e = strRx.replace(e) { m -> strs.add(m.value); "\u0000${strs.size - 1}\u0000" }
        for ((rx, rep) in apiRules) e = rx.replace(e) { m -> expand(rep, m) }
        e = Regex("\\bPlayState\\.instance\\b").replace(e, "__portyou_playstate")
        e = Regex("\\bnull\\b").replace(e, "nil")
        e = e.replace("!=", "~=").replace("&&", " and ").replace("||", " or ")
        e = Regex("!(?!=)\\s*").replace(e, "not ")
        e = Regex("\\bthis\\.").replace(e, "")
        e = Regex(":\\s*(?:Int|Float|String|Bool|Dynamic|Array<\\w+>)\\b").replace(e, "")
        e = Regex("\\bStd\\.int\\s*\\(").replace(e, "math.floor(")
        e = Regex("\\bMath\\.PI\\b").replace(e, "math.pi")
        e = Regex("\\bMath\\.round\\(([^()]*)\\)").replace(e) { "math.floor((${it.groupValues[1]}) + 0.5)" }
        e = Regex("\\bMath\\.(floor|ceil|abs|sin|cos|sqrt|min|max|random|pow)\\b").replace(e) { "math." + it.groupValues[1] }
        e = Regex("\\bFlxMath\\.lerp\\(").replace(e, "__portyou_lerp(")
        e = Regex("\\bFlxMath\\.bound\\(").replace(e, "__portyou_bound(")
        e = Regex("\\bFlxG\\.elapsed\\b").replace(e, "elapsed")
        e = Regex("([A-Za-z_][A-Za-z0-9_]*(?:\\.[A-Za-z_][A-Za-z0-9_]*)*)\\.concat\\(").replace(e) { "__portyou_concat(${it.groupValues[1]}, " }
        e = Regex("\\b(\\w+)\\.length\\b").replace(e) { "#" + it.groupValues[1] }
        e = Regex("\\bmath\\.pow\\(([^,()]+),\\s*([^()]+)\\)").replace(e) { "(${it.groupValues[1]} ^ ${it.groupValues[2]})" }
        // Haxe object literals and maps -> valid Lua table constructors.
        e = Regex("(\\u0000\\d+\\u0000)\\s*=>\\s*(\\u0000\\d+\\u0000)").replace(e) { "[${it.groupValues[1]}] = ${it.groupValues[2]}" }
        e = Regex("([,{]\\s*)([A-Za-z_][A-Za-z0-9_]*)\\s*:").replace(e) { "${it.groupValues[1]}${it.groupValues[2]} =" }
        // Haxe's null-safe property chain -> safe table lookup helper.
        e = Regex("\\b([A-Za-z_][A-Za-z0-9_]*)((?:\\?\\.[A-Za-z_][A-Za-z0-9_]*)+)").replace(e) { m ->
            val keys = Regex("\\?\\.([A-Za-z_][A-Za-z0-9_]*)").findAll(m.groupValues[2]).joinToString(", ") { "'${it.groupValues[1]}'" }
            "__portyou_safe_path(${m.groupValues[1]}, $keys)"
        }
        // Enum members are represented by stable string keys; this keeps switch/assignment pairs consistent.
        e = Regex("\\b([A-Z][A-Za-z0-9_]*(?:State|Kind|Type|Mode))\\.([A-Z][A-Za-z0-9_]*)\\b").replace(e) { "'${it.groupValues[2]}'" }
        // Haxe ternary -> Lua short-circuit expression. Recurse into nested groups first,
        // since many Haxe files wrap each ternary in parentheses.
        fun ternary(expr0: String): String {
            fun matchingClose(s: String, start: Int): Int {
                val stack = ArrayList<Char>(); var quote: Char? = null; var j = start
                while (j < s.length) {
                    val c = s[j]
                    if (quote != null) {
                        if (c == '\\') j++ else if (c == quote) quote = null
                    } else when (c) {
                        '\'' , '\"' -> quote = c
                        '(' -> stack.add(')')
                        '[' -> stack.add(']')
                        '{' -> stack.add('}')
                        ')', ']', '}' -> {
                            if (stack.isNotEmpty() && stack.last() == c) {
                                stack.removeAt(stack.lastIndex)
                                if (stack.isEmpty()) return j
                            }
                        }
                    }
                    j++
                }
                return -1
            }
            val nested = StringBuilder(); var i = 0; var quote: Char? = null
            while (i < expr0.length) {
                val c = expr0[i]
                if (quote != null) {
                    nested.append(c)
                    if (c == '\\' && i + 1 < expr0.length) { nested.append(expr0[i + 1]); i += 2; continue }
                    if (c == quote) quote = null
                    i++; continue
                }
                if (c == '\'' || c == '\"') { quote = c; nested.append(c); i++; continue }
                if (c == '(' || c == '[' || c == '{') {
                    val close = matchingClose(expr0, i)
                    if (close > i) {
                        nested.append(c).append(ternary(expr0.substring(i + 1, close))).append(expr0[close])
                        i = close + 1; continue
                    }
                }
                nested.append(c); i++
            }
            val expr = nested.toString()
            var dep = 0; quote = null; var qAt = -1; var colonAt = -1; var nestedQuestions = 0; i = 0
            while (i < expr.length) {
                val c = expr[i]
                if (quote != null) { if (c == '\\') { i += 2; continue }; if (c == quote) quote = null }
                else if (c == '\'' || c == '\"') quote = c
                else if (c == '(' || c == '[' || c == '{') dep++
                else if (c == ')' || c == ']' || c == '}') dep--
                else if (dep == 0 && c == '?' && (i + 1 >= expr.length || expr[i + 1] != '?')) { qAt = i; break }
                i++
            }
            if (qAt < 0) return expr
            dep = 0; quote = null; i = qAt + 1
            while (i < expr.length) {
                val c = expr[i]
                if (quote != null) { if (c == '\\') { i += 2; continue }; if (c == quote) quote = null }
                else if (c == '\'' || c == '\"') quote = c
                else if (c == '(' || c == '[' || c == '{') dep++
                else if (c == ')' || c == ']' || c == '}') dep--
                else if (dep == 0 && c == '?' && (i + 1 >= expr.length || expr[i + 1] != '?')) nestedQuestions++
                else if (dep == 0 && c == ':') {
                    if (nestedQuestions == 0) { colonAt = i; break }
                    nestedQuestions--
                }
                i++
            }
            if (colonAt < 0) throw Unconvertible("invalid ternary expression")
            val condition = ternary(expr.substring(0, qAt).trim())
            val yes = ternary(expr.substring(qAt + 1, colonAt).trim())
            val no = ternary(expr.substring(colonAt + 1).trim())
            // Avoid Lua's `and/or` pseudo-ternary: it returns the else value when the true branch is false or nil.
            // An immediately-invoked closure preserves Haxe ternary semantics and lazy branch evaluation.
            return "(function() if $condition then return $yes else return $no end end)()"
        }
        if (e.contains("?") && !e.contains("??")) e = ternary(e)
        // Null coalescing must preserve false/zero (unlike Lua's plain `or`).
        if (e.contains("??")) {
            val pair = Regex("^(.+?)\\s*\\?\\?\\s*(.+)$", RegexOption.DOT_MATCHES_ALL).matchEntire(e)
                ?: throw Unconvertible("unsupported null-coalescing expression")
            e = "coalesce(${pair.groupValues[1]}, ${pair.groupValues[2]})"
        }
        if (e.contains('\u0000')) {      // '+' next to a string literal is concatenation
            e = Regex("(\u0000\\d+\u0000)\\s*\\+").replace(e) { it.groupValues[1] + " .." }
            e = Regex("\\+\\s*(\u0000\\d+\u0000)").replace(e) { ".. " + it.groupValues[1] }
            e = Regex("\\.\\.\\s*(\\w[\\w.\\[\\]()]*)\\s*\\+\\s*(?=\u0000|\\w)").replace(e) { ".. ${it.groupValues[1]} .. " }
        }
        if (Regex("\\[\\s*\\]").matches(e)) e = "{}"
        if (Regex("\\[[^\\]]*\\]").matches(e) && !Regex("\\w\\[").containsMatchIn(e)) e = "{" + e.substring(1, e.length - 1) + "}"
        for ((i, sx) in strs.withIndex()) e = e.replace("\u0000$i\u0000", sx)
        val bare = strRx.replace(e, "")
        leftRx.find(bare)?.let { throw Unconvertible("engine API without a Lua equivalent yet: " + it.value) }
        if (e.contains("=>") || e.contains("->") || Regex("\\bnew\\s+\\w").containsMatchIn(e)) throw Unconvertible("lambda / constructor / map literal")
        return e.trim()
    }

    private fun convBlock(body: String, indent: Int = 1): List<String> {
        val out = ArrayList<String>()
        for (st in splitStatements(body)) out += convStmt(st.trim(), indent)
        return out
    }

    private fun splitStatements(body: String): List<String> {
        val res = ArrayList<String>(); var cur = StringBuilder(); var d = 0; var q: Char? = null; var i = 0; val n = body.length
        while (i < n) {
            val c = body[i]
            if (q != null) {
                cur.append(c)
                if (c == '\\' && i + 1 < n) { cur.append(body[i + 1]); i += 2; continue }
                if (c == q) q = null
                i++; continue
            }
            if (c == '"' || c == '\'') { q = c; cur.append(c) }
            else if (c == '(' || c == '[') { d++; cur.append(c) }
            else if (c == ')' || c == ']') { d--; cur.append(c) }
            else if (c == '{' && d == 0) {
                val end = matchBrace(body, i)
                cur.append(body, i, end + 1); i = end + 1
                val rest = body.substring(i).trimStart()
                if (Regex("^(else|catch)\\b").containsMatchIn(rest)) continue
                if (cur.isNotBlank()) res.add(cur.toString())
                cur = StringBuilder(); continue
            } else if (c == ';' && d == 0) { if (cur.isNotBlank()) res.add(cur.toString()); cur = StringBuilder() }
            else cur.append(c)
            i++
        }
        if (cur.isNotBlank()) res.add(cur.toString())
        return res
    }

    private fun headAndBlock(st: String, kw: String): Pair<String, String>? {
        val m = Regex("^$kw\\s*\\(").find(st) ?: return null
        val i = m.range.last; var d = 0
        for (j in i until st.length) {
            if (st[j] == '(') d++ else if (st[j] == ')') { d--; if (d == 0) return st.substring(i + 1, j) to st.substring(j + 1).trim() }
        }
        throw Unconvertible("unbalanced parentheses")
    }

    private fun blockOf(rest0: String): Pair<String, String> {
        val rest = rest0.trim()
        if (rest.startsWith("{")) { val end = matchBrace(rest, 0); return rest.substring(1, end) to rest.substring(end + 1).trim() }
        val parts = splitStatements(rest)
        return (parts.firstOrNull() ?: "") to ""
    }

    private val reLocal = Regex("(?:final|var)\\s+(\\w+)\\s*(?::\\s*[\\w.<>]+)?\\s*(?:=\\s*(.*))?", RegexOption.DOT_MATCHES_ALL)
    private val reCompound = Regex("(.+?)\\s*([+\\-*/])=\\s*(.+)", RegexOption.DOT_MATCHES_ALL)
    private val reIncr = Regex("(\\w[\\w.\\[\\]]*)\\s*(\\+\\+|--)")
    private val reAssign1 = Regex("([^=<>!]+?)\\s=\\s(?!=)(.+)", RegexOption.DOT_MATCHES_ALL)
    private val reAssign2 = Regex("([\\w.\\[\\]()'\"]+)\\s*=(?!=)\\s*(.+)", RegexOption.DOT_MATCHES_ALL)

    private data class SwitchCase(val values: String?, val body: String)

    /** Conservative Haxe switch lowering. Patterns/case guards are kept for the failure report. */
    private fun convSwitch(st: String, ind: Int): List<String> {
        val head = Regex("^switch\\s*\\(").find(st) ?: throw Unconvertible("invalid switch")
        val open = head.range.last
        var depth = 0; var close = -1; var quote: Char? = null; var i = open
        while (i < st.length) {
            val ch = st[i]
            if (quote != null) {
                if (ch == '\\') { i += 2; continue }
                if (ch == quote) quote = null
            } else if (ch == '\'' || ch == '\"') quote = ch
            else if (ch == '(') depth++
            else if (ch == ')') { depth--; if (depth == 0) { close = i; break } }
            i++
        }
        if (close < 0) throw Unconvertible("unbalanced switch expression")
        val expr = st.substring(open + 1, close).trim()
        val rest = st.substring(close + 1).trim()
        if (!rest.startsWith("{")) throw Unconvertible("switch block expected")
        val end = matchBrace(rest, 0)
        if (rest.substring(end + 1).isNotBlank()) throw Unconvertible("extra code after switch")
        val body = rest.substring(1, end)
        val cases = ArrayList<SwitchCase>()
        var pos = 0; var labelStart = -1; var labelValues: String? = null
        var brace = 0; var paren = 0; var bracket = 0; quote = null; i = 0
        fun addCase(endAt: Int) {
            if (labelStart >= 0) cases.add(SwitchCase(labelValues, body.substring(labelStart, endAt)))
        }
        while (i < body.length) {
            val ch = body[i]
            if (quote != null) {
                if (ch == '\\') { i += 2; continue }
                if (ch == quote) quote = null
            } else if (ch == '\'' || ch == '\"') quote = ch
            else if (ch == '{') brace++
            else if (ch == '}') brace--
            else if (ch == '(') paren++
            else if (ch == ')') paren--
            else if (ch == '[') bracket++
            else if (ch == ']') bracket--
            if (brace == 0 && paren == 0 && bracket == 0 && quote == null) {
                val isCase = body.startsWith("case", i) && (i == 0 || !body[i - 1].isLetterOrDigit() && body[i - 1] != '_')
                val isDefault = body.startsWith("default", i) && (i == 0 || !body[i - 1].isLetterOrDigit() && body[i - 1] != '_')
                if (isCase || isDefault) {
                    var colon = i + if (isCase) 4 else 7
                    var pd = 0; var q: Char? = null
                    while (colon < body.length) {
                        val c = body[colon]
                        if (q != null) { if (c == '\\') { colon += 2; continue }; if (c == q) q = null }
                        else if (c == '\'' || c == '\"') q = c
                        else if (c == '(' || c == '[') pd++
                        else if (c == ')' || c == ']') pd--
                        else if (c == ':' && pd == 0) break
                        colon++
                    }
                    if (colon >= body.length) throw Unconvertible("switch case missing colon")
                    addCase(i)
                    val raw = body.substring(i + if (isCase) 4 else 7, colon).trim()
                    if (isCase && raw.isEmpty()) throw Unconvertible("empty switch case")
                    if (raw.contains(" if ")) throw Unconvertible("guarded switch case is unsupported")
                    labelValues = if (isCase) raw else null
                    labelStart = colon + 1
                    i = colon + 1
                    continue
                }
            }
            i++
        }
        addCase(body.length)
        if (cases.isEmpty()) throw Unconvertible("switch cases were not recognised")
        val defaultCase = cases.firstOrNull { it.values == null }
        val normalCases = cases.filter { it.values != null }
        switchCounter++
        val temp = "__portyou_switch_$switchCounter"
        val pad = "\t".repeat(ind)
        val lines = ArrayList<String>()
        lines.add("${pad}local $temp = ${convExpr(expr)}")
        for ((index, c) in normalCases.withIndex()) {
            val values = splitSwitchValues(c.values!!)
            if (values.isEmpty()) throw Unconvertible("unsupported switch case pattern")
            val cond = values.joinToString(" or ") { "$temp == ${convExpr(it)}" }
            lines.add("${pad}${if (index == 0) "if" else "elseif"} $cond then")
            val caseBody = c.body.replace(Regex("(?m)\\bbreak\\s*;?\\s*$"), "")
            lines += convBlock(caseBody, ind + 1)
        }
        if (defaultCase != null) {
            if (normalCases.isEmpty()) lines.add("${pad}do") else lines.add("${pad}else")
            lines += convBlock(defaultCase.body.replace(Regex("(?m)\\bbreak\\s*;?\\s*$"), ""), ind + 1)
            if (normalCases.isEmpty()) lines.add("${pad}end")
        }
        if (normalCases.isNotEmpty()) lines.add("${pad}end")
        return lines
    }

    private fun splitSwitchValues(src: String): List<String> {
        val out = ArrayList<String>(); var start = 0; var depth = 0; var q: Char? = null; var i = 0
        while (i < src.length) {
            val c = src[i]
            if (q != null) { if (c == '\\') { i += 2; continue }; if (c == q) q = null }
            else if (c == '\'' || c == '\"') q = c
            else if (c == '(' || c == '[') depth++
            else if (c == ')' || c == ']') depth--
            else if (c == ',' && depth == 0) { out.add(src.substring(start, i).trim()); start = i + 1 }
            i++
        }
        out.add(src.substring(start).trim())
        return out.filter { it.isNotEmpty() }
    }

    private fun convStmt(st: String, ind: Int): List<String> {
        val pad = "\t".repeat(ind)
        if (st.isEmpty()) return emptyList()
        if (Regex("^switch\\b").containsMatchIn(st)) return convSwitch(st, ind)
        if (Regex("^(try|do)\\b").containsMatchIn(st)) throw Unconvertible("try / do-while")
        headAndBlock(st, "if")?.let { (cond0, rest0) ->
            var cond = cond0; var rest = rest0; val lines = ArrayList<String>(); var first = true
            while (true) {
                val (body, r1) = blockOf(rest); rest = r1
                lines.add("$pad${if (first) "if" else "elseif"} ${convExpr(cond)} then")
                lines += convBlock(body, ind + 1); first = false
                if (rest.startsWith("else")) {
                    rest = rest.substring(4).trim()
                    val r2 = headAndBlock(rest, "if")
                    if (r2 != null) { cond = r2.first; rest = r2.second; continue }
                    val (b2, r3) = blockOf(rest); rest = r3
                    lines.add(pad + "else"); lines += convBlock(b2, ind + 1)
                }
                break
            }
            lines.add(pad + "end"); return lines
        }
        headAndBlock(st, "for")?.let { (head, rest) ->
            val (body, _) = blockOf(rest)
            val lines = ArrayList<String>()
            val m = Regex("\\s*(\\w+)\\s+in\\s+(.+?)\\.\\.\\.(.+)").matchEntire(head)
            if (m != null) lines.add("${pad}for ${m.groupValues[1]} = ${convExpr(m.groupValues[2])}, ${convExpr("(${m.groupValues[3]}) - 1")} do")
            else {
                val m2 = Regex("\\s*(\\w+)\\s+in\\s+(.+)").matchEntire(head) ?: throw Unconvertible("for-loop form")
                lines.add("${pad}for _, ${m2.groupValues[1]} in ipairs(${convExpr(m2.groupValues[2])}) do")
            }
            lines += convBlock(body, ind + 1); lines.add(pad + "end"); return lines
        }
        headAndBlock(st, "while")?.let { (cond, rest) ->
            val (body, _) = blockOf(rest)
            return listOf("${pad}while ${convExpr(cond)} do") + convBlock(body, ind + 1) + listOf(pad + "end")
        }
        if (st.startsWith("{")) { val end = matchBrace(st, 0); return listOf(pad + "do") + convBlock(st.substring(1, end), ind + 1) + listOf(pad + "end") }
        if (st.startsWith("return")) { val v = st.substring(6).trim(); return listOf(pad + if (v.isNotEmpty()) "return " + convExpr(v) else "do return end") }
        if (st == "break" || st == "continue") {
            if (st == "continue") throw Unconvertible("continue (no Lua equivalent without goto)")
            return listOf(pad + "break")
        }
        reLocal.matchEntire(st)?.let { m -> return listOf("${pad}local ${m.groupValues[1]}" + (if (m.groups[2] != null && m.groupValues[2].isNotEmpty()) " = " + convExpr(m.groupValues[2]) else "")) }
        reCompound.matchEntire(st)?.let { m ->
            if (!Regex("[=<>!]=").containsMatchIn(m.groupValues[1])) {
                val t = convExpr(m.groupValues[1])
                val op = if (m.groupValues[2] == "+" && Regex("'|\"").containsMatchIn(m.groupValues[3])) ".." else m.groupValues[2]
                return listOf("$pad$t = $t $op ${convExpr(m.groupValues[3])}")
            }
        }
        reIncr.matchEntire(st)?.let { m -> return listOf("$pad${m.groupValues[1]} = ${m.groupValues[1]} ${m.groupValues[2][0]} 1") }
        if (st.contains(" = ") && !Regex("==|!=|<=|>=").containsMatchIn(st)) {
            val chain = st.split(Regex("\\s*=\\s*"))
            if (chain.size >= 3 && chain.dropLast(1).all { it.matches(Regex("[A-Za-z_][A-Za-z0-9_.'\\[\\]]*")) }) {
                val value = convExpr(chain.last())
                return chain.dropLast(1).map { "$pad${convExpr(it)} = $value" }
            }
        }
        (reAssign1.matchEntire(st) ?: reAssign2.matchEntire(st))?.let { m -> return listOf("$pad${convExpr(m.groupValues[1])} = ${convExpr(m.groupValues[2])}") }
        return listOf(pad + convExpr(st))
    }

    /** guards odd output: every opener has its end, brackets match */
    private fun luaBalanced(code0: String): Boolean {
        val code = Regex("'(?:\\\\.|[^'\\\\])*'|\"(?:\\\\.|[^\"\\\\])*\"|--[^\\n]*").replace(code0, "")
        val opens = Regex("\\b(function|if|for|while|do)\\b").findAll(code).count() -
            Regex("\\bfor\\b[^\\n]*\\bdo\\b|\\bwhile\\b[^\\n]*\\bdo\\b").findAll(code).count()
        return opens == Regex("\\bend\\b").findAll(code).count() && code.count { it == '(' } == code.count { it == ')' } && code.count { it == '{' } == code.count { it == '}' }
    }

    // ------------------------------------------------------------------ file level
    fun convertSource(src: String, kind: String, name: String): Pair<String, Result> {
        moduleInitializers.clear()
        val r = Result(); val lines = ArrayList<String>()
        lines.add("-- PortYou Studio: converted from $name ($kind)")
        lines.add("local function __portyou_safe_path(v, ...) for i = 1, select('#', ...) do if v == nil then return nil end; local k = select(i, ...); v = v[k] end; return v end")
        lines.add("local function coalesce(a,b) if a == nil then return b end return a end")
        lines.add("local function __portyou_lerp(a,b,t) return a + (b-a)*t end")
        lines.add("local function __portyou_bound(v,lo,hi) return math.max(lo, math.min(hi,v)) end")
        lines.add("local function __portyou_remap(v,a,b,c,d) if b == a then return c end; return c + (v-a) / (b-a) * (d-c) end")
        lines.add("local function __portyou_concat(a,b) local r={}; for i=1,#(a or {}) do r[#r+1]=a[i] end; for i=1,#(b or {}) do r[#r+1]=b[i] end; return r end")
        lines.add("local function __portyou_camera(n) return setmetatable({}, {__index=function(_,k) return getProperty(n..'.'..k) end, __newindex=function(_,k,v) setProperty(n..'.'..k,v) end}) end")
        lines.add("local __portyou_playstate = setmetatable({}, {__index=function(_,k) if k == 'camGame' then return __portyou_camera('camGame') elseif k == 'camHUD' then return __portyou_camera('camHUD') elseif k == 'health' then return getProperty('health') end; return getProperty(k) end})")
        val prepared = prepareModuleClasses(src)
        if (prepared.second) {
            lines.add("local __portyou_modules = setmetatable({}, {__index=function(t,k) local v={}; rawset(t,k,v); return v end})")
            for (init in moduleInitializers) try { lines += convStmt(init, 0) }
            catch (ex: Unconvertible) { r.failed.add(Failure(name, "<module field>", ex.message ?: "", init)) }
        }
        val members = splitMembers(prepared.first)
        if (members.isEmpty()) r.failed.add(Failure(name, "<file>", "no functions or variables recognised", src.trim().take(4000)))
        for (mem in members) {
            when (mem) {
                is Member.Var -> try {
                    lines += convStmt(mem.text.trim().trimEnd(';').replace("public ", "").replace("static ", "").replace("private ", ""), 0)
                } catch (ex: Unconvertible) { r.failed.add(Failure(name, "<variable>", ex.message ?: "", mem.text)) }
                is Member.Fn -> {
                    if (mem.name == "new") continue
                    val lname = callbacks[mem.name] ?: mem.name
                    val params = mem.args.split(',').map { it.replace(Regex("\\s*[:=].*$"), "").trim() }.filter { it.isNotEmpty() }
                    try {
                        val code = convBlock(mem.body)
                        val lua = (listOf("function $lname(${params.joinToString(", ")})") + code + listOf("end")).joinToString("\n")
                        if (!luaBalanced(lua)) throw Unconvertible("result did not pass the syntax balance check")
                        lines.add(lua); r.ok++
                    } catch (ex: Unconvertible) {
                        r.failed.add(Failure(name, mem.name, ex.message ?: "", "function ${mem.name}(${mem.args}) {${mem.body}}"))
                        lines.add("-- PortYou: function \"${mem.name}\" was NOT converted (${ex.message})")
                    } catch (ex: StackOverflowError) {
                        r.failed.add(Failure(name, mem.name, "too deeply nested", "function ${mem.name}(${mem.args}) {${mem.body}}"))
                    }
                }
            }
        }
        return lines.joinToString("\n") + "\n" to r
    }

    /** V-Slice SongEvent.handleEvent(data) -> Psych custom event onEvent(name, v1, v2); data.value = parsed 'k=v;k=v' */
    private fun eventWrapper(kind: String, lua0: String): String {
        val lua = lua0.replace(Regex("\\bfunction handleEvent\\("), "local function handleEvent(")
        val q = "'" + kind.replace("\\", "\\\\").replace("'", "\\'") + "'"
        val pre = "local function coalesce(a,b) if a == nil then return b end return a end\n" +
            "local function _parse(s) local t = {} for kv in string.gmatch(s or \"\", \"[^;]+\") do local k, v = string.match(kv, \"^([^=]+)=(.*)\") " +
            "if k then if v == \"true\" then t[k] = true elseif v == \"false\" then t[k] = false else t[k] = tonumber(v) or v end end end return t end\n"
        val wrapper = "\nfunction onEvent(name, v1, v2)\n" +
            "\tif name == $q then\n" +
            "\t\tlocal data = {value = _parse(v1), event = name}\n" +
            "\t\tdata.getFloat = function(k) local v = data.value[k]; if v == nil then return nil end; return tonumber(v) end\n" +
            "\t\tdata.getInt = function(k) local v = data.value[k]; if v == nil then return nil end; return math.floor(tonumber(v) or 0) end\n" +
            "\t\tdata.getBool = function(k) local v = data.value[k]; if v == nil then return nil end; return v == true or v == 1 or v == '1' or v == 'true' end\n" +
            "\t\tdata.getString = function(k) local v = data.value[k]; if v == nil then return nil end; return tostring(v) end\n" +
            "\t\tpcall(handleEvent, data)\n\tend\nend\n"
        return pre + lua + wrapper
    }

    /** Writes Lua into outDir (the mod root). Whatever cannot be converted is written OUT of the mod into unconvertedDir with a 4-language report. */
    fun convertMany(files: List<HxFile>, outDir: File, unconvertedDir: File): Pair<Int, List<Failure>> {
        val failures = ArrayList<Failure>(); var okFiles = 0
        for (f in files) {
            val base = f.path.nameWithoutExtension
            val res: Pair<String, Result> = try { convertSource(f.path.readText(), f.kind, f.path.name) }
                catch (ex: Exception) { failures.add(Failure(f.path.name, "<file>", ex.message ?: "", "")); continue }
            var lua = res.first; val r = res.second
            if (r.ok > 0) {
                val dest: File = when (f.kind) {
                    "event" -> { lua = eventWrapper(f.event ?: base, lua); File(outDir, "custom_events/${f.event ?: base}.lua") }
                    "stage" -> File(outDir, "stages/$base.lua").also { if (it.isFile) lua = it.readText() + "\n" + lua }
                    "notetype" -> File(outDir, "custom_notetypes/$base.lua")
                    else -> File(outDir, "scripts/hx_$base.lua")
                }
                dest.parentFile?.mkdirs(); dest.writeText(lua); okFiles++
            }
            failures += r.failed
            if (f.kind == "notetype" && r.ok == 0 && r.failed.isEmpty()) {
                failures.add(Failure(f.path.name, "<note kind>", "constructor-only note kind: it defines a suffix but no runtime callback, so it needs a Psych note-type mapping", f.path.readText()))
            }
        }
        if (failures.isNotEmpty()) writeUnconverted(failures, unconvertedDir)
        return okFiles to failures
    }

    private val head = mapOf(
        "ar" to "ماقدرت أحول هذا — أجزاء من أكواد الهاكس لم يستطع المحوّل تحويلها إلى لوا. تم فصلها عن المود وهذه قائمتها:",
        "en" to "Could not convert this — parts of the Haxe code could not be turned into Lua. They were separated from the mod; here is the list:",
        "pt" to "Não consegui converter isto — partes do código Haxe não puderam virar Lua. Foram separadas do mod; segue a lista:",
        "ja" to "これは変換できませんでした — Haxeコードの一部をLuaに変換できませんでした。MODから分離済みです。一覧:")

    private fun writeUnconverted(failures: List<Failure>, d: File) {
        d.mkdirs()
        val txt = ArrayList<String>()
        for ((l, h) in head) txt.add("=".repeat(60) + "\n[$l] $h\n")
        txt.add("=".repeat(60))
        for (f in failures) txt.add("\n* ${f.file} :: ${f.fn}\n    reason: ${f.why}")
        File(d, "ماقدرت_احول_ذا_COULD_NOT_CONVERT.txt").writeText(txt.joinToString("\n") + "\n")
        val raw = File(d, "haxe_sources").also { it.mkdirs() }
        for (f in failures) if (f.code.isNotEmpty()) File(raw, "${f.file.substringBeforeLast('.')}__${f.fn.replace(Regex("\\W"), "_")}.hx").writeText(f.code)
    }
}
