# PortYou Studio

Offline Android app for converting **Funky Maker (.FNMM)** and **V-Slice** mods to **Psych Engine 1.0.4**.

## Current project status

| Area | Current status |
|---|---|
| Archive import | Reads the archive contents and detects FNMM/V-Slice independently of the selected button or extension. |
| Funky Maker | Kotlin converter supports both legacy scene coordinates and FNMM v4 transform arrays; Python reference converter was tested with the supplied FNMM archive. |
| V-Slice | Kotlin converter handles charts, events, characters, stages, assets and Haxe script translation. Some Haxe APIs/shaders remain unsupported and are reported. |
| Haxe examples | Uses a compact gzip knowledge index derived from 4,193 example files; it does not bundle the original 90.4 MB archive and is not a generative AI. |
| Large atlases | Sparrow frames can be repacked into multiple transparent PNG pages, each no larger than 4096×4096. A single frame larger than this limit remains unsupported. |
| UI strings | Akram bubble placement and the Algerian phrase set are updated. |

## Build

GitHub Actions workflow: `Build APK` (when configured in the repository). Local build requires JDK 17, Android SDK 34 and Gradle:

```bash
gradle :app:assembleRelease
```

This source archive does not include a built APK. A complete Android build and on-device test were not available in the current repair environment; see [FIXES_AR.md](FIXES_AR.md) for the exact validation performed and known limitations.

## Developer tools

- `tools/fnmm_to_psych.py` — reference FNMM converter (includes v4 transform support).
- `tools/fnmm_runtime.lua` — runtime for FNMM events and scene objects.
- `tools/portyou/hx2lua.py` and `tools/portyou/methods.json` — reference Haxe conversion rules.
- `app/src/main/java/com/portyou/studio/convert/` — Android/Kotlin implementation.

## Credits

App by axelzerox023 — [YouTube](https://youtube.com/@axelzerox023) · [Instagram](https://www.instagram.com/axelzerox023)
Friend: Akram — [YouTube](https://youtube.com/@akrammakak-official)
